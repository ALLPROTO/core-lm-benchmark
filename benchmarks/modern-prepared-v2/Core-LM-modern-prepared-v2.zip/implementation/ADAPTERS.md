# Experimental attention adapters for the modern-baseline matrix

These modules extend the prior eager optimization to the registered head dimensions 64 and 128 and model families `qwen2` / `llama`. They do not establish performance or real-model quality by themselves. Stock Hugging Face SDPA stays an independent, untouched baseline.

## Harness contract

One model / arm per fresh process. Pinned runtime: PyTorch 2.13.0, Transformers 5.14.1, Triton 3.7.1; CUDA runtime/version checks belong to the harness. All measurements use actual pinned pretrained models and registered public text; generated values below belong only to isolated unit controls.

```python
from attention_adapters import install_candidate, install_lower_right_sdpa
# Native eager baseline: model created with attn_implementation='eager', no adapter.
# Stock HF SDPA baseline: model created with attn_implementation='sdpa', no adapter.

# Candidate: model created with attn_implementation='eager'.
stats = install_candidate(model)

# Separate lower-right control: model created with attn_implementation='sdpa'.
# Probe validates actual incoming masks, including padding/window rejection.
stats = install_lower_right_sdpa(model, validate_masks=True)
# Independent fresh timing/memory worker, only AFTER matching semantic probe:
stats = install_lower_right_sdpa(model, validate_masks=False)
```

Both return JSON-safe mutable counters. The harness owns hard pass/fail gates, full output retention, actual kernel profiling, lifecycle memory observation and speed statistics. No CPU fallback exists for the fused candidate. `restore_adapter(model)` is for isolated tests/cleanup, not switching benchmark arms in one process.

## Candidate

For query lengths ≤1536, native eager remains unchanged. Longer calls use the original GEMMs, full K/V and native FP32 softmax with whole-private-buffer alias. One fixed Triton kernel performs FP32 multiplication, BF16 round-to-nearest-even, FP32 addition of the full supplied mask, another BF16 rounding, and FP32 output. Scaling constants for head64/head128 are converted to FP32, matching native BF16 opmath. Inline PTX fixes `mul.rn.f32`, `add.rn.f32` and explicit BF16 casts; no autotuning or fused multiply-add is used. CUDA bit equality must be re-established for each real model/condition.

## Lower-right SDPA control

This is explicitly NOT stock HF SDPA. It installs a module-local `AttentionInterface['sdpa']` override, preserving global stock registry and all model projection/rotary/cache logic. HF mask construction is retained, including its allocation cost. For square prefill, it calls ordinary SDPA with implicit causal masking. For continuation, it uses PyTorch `causal_lower_right(Q,K)` with the complete actual K/V tensors. GQA is enabled only when Q heads differ from KV heads. Flash/efficient/math dispatch is automatic; no particular optimized kernel is claimed without the separate GPU probe.

Only the registered no-padding batch1 decoder workload is supported. In the safe probe mode, supplied masks must exactly equal the lower-right causal pattern. Floating masks may contain only zeros on allowed entries and negative infinity or the dtype minimum on blocked entries. Mask checks can synchronize and allocate diagnostic tensors, so they are excluded only by the explicit `validate_masks=False` argument in a separately validated workload. This flag is a caller contract, not a generally safe replacement for arbitrary masks. It must not be used for padding, sliding windows, position biases or unknown masks.

A probe wrapping `torch.nn.functional.scaled_dot_product_attention` should verify actual Q/K dimensions against workload phase, not merely cache lengths. `validate_lower_right_mask` also understands a `CausalBias` with matching complete dimensions; for raw None masks, the probe must separately check the `is_causal` argument. A correct lower-right mask cannot repair K/V that were truncated before the probe.

## Local controls, not benchmark evidence

```
export PYTHONPATH=/workspace/scratch/5b0626224660/corelm-speed-next/triton-runtime:/workspace/scratch/5b0626224660/corelm-speed-next/cpu-runtime
python tests/test_adapters.py
TRITON_CACHE_DIR=/tmp/corelm-modern-offline-test python tests/compile_sm86.py
```

The 8 CPU tests include all finite BF16 patterns for both scaling values, real tiny Qwen/Llama API wiring with a substituted CPU arithmetic oracle, actual CPU SDPA lower-right semantics, stock-registry isolation, input-mask preservation and fail-closed guards. Four offline SM86 compiler controls cover masked/unmasked head64/head128 kernels and reject FMA/FTZ. These tests never run CUDA, never produce pretrained-model evidence, and never justify a speed or memory claim.
