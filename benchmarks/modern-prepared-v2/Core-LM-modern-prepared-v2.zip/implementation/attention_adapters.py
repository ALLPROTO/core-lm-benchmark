"""Experimental fixed-workload adapters. No unmeasured performance claims.

One adapter/model family per fresh process. CPU fixture execution is for tests
only. Production fused code has no CPU fallback. Lower-right SDPA is a separate
named control, NOT stock HF SDPA; ordinary ``attn_implementation='sdpa'`` remains
the stock baseline when no adapter is installed.
"""
import hashlib
import importlib
import inspect

EAGER_SHA256 = 'cb34ccea28710ae8d5d94a241b704ea3d974048f85372f0b1b3c2a8a2ef1ee20'
SDPA_SHA256 = '6bfcee4b4e17e13483bd7a5a11754c79b30b073eee269ec0bd95296cecf95b33'
CAUSAL_DISPATCH_SHA256 = '076b24db91ce4509c12fe1eb620e21bf99cb503b4e311fe5c50aa9fd11e757a9'
SHORT_NATIVE_THRESHOLD = 1536
_INSTALLED = {}


def _source_guard(fn, expected):
    actual = hashlib.sha256(inspect.getsource(fn).encode()).hexdigest()
    if actual != expected:
        raise RuntimeError(f'Pinned source mismatch for {fn.__module__}.{fn.__name__}: {actual}')
    return actual


def _model_module(model):
    import transformers
    if transformers.__version__ != '5.14.1':
        raise RuntimeError('Pinned Transformers 5.14.1 required')
    family = model.config.model_type
    if family not in ('qwen2', 'llama'):
        raise ValueError('Only registered qwen2/llama model families supported')
    if family in _INSTALLED:
        raise RuntimeError('An adapter is already installed for this model family; use a fresh worker')
    head_dim = getattr(model.config, 'head_dim', None) or model.config.hidden_size // model.config.num_attention_heads
    if head_dim not in (64, 128):
        raise ValueError('Only registered head dimensions 64/128 supported')
    if getattr(model.config, 'output_attentions', False):
        raise ValueError('output_attentions=True unsupported')
    if getattr(model.config, 'use_sliding_window', False):
        raise ValueError('Sliding-window attention is outside this protocol')
    module = importlib.import_module(f'transformers.models.{family}.modeling_{family}')
    _source_guard(module.eager_attention_forward, EAGER_SHA256)
    return family, module, head_dim


def _inference_guard(module, dropout, kwargs):
    import torch
    if torch.is_grad_enabled() or module.training or dropout != 0 or kwargs.get('output_attentions', False):
        raise RuntimeError('Adapter supports no-grad inference without dropout/attention output only')
    if kwargs.get('sliding_window') is not None:
        raise ValueError('Sliding-window attention is outside this protocol')


def restore_adapter(model):
    """Test/cleanup helper, not called between benchmark arms (fresh processes)."""
    saved = _INSTALLED.pop(model.config.model_type, None)
    if saved:
        module, eager, interface, old_impl = saved
        module.eager_attention_forward = eager
        module.ALL_ATTENTION_FUNCTIONS = interface
        model.config._attn_implementation = old_impl


def install_candidate(model):
    """Install fused eager scratch-buffer optimization; return JSON-safe counters."""
    import torch
    from fused_scale_mask import scale_mask_to_fp32, BLOCK_SIZE, NUM_WARPS
    family, module, head_dim = _model_module(model)
    native = module.eager_attention_forward
    _INSTALLED[family] = (module, native, module.ALL_ATTENTION_FUNCTIONS, model.config._attn_implementation)
    stats = {'mode': 'fused_eager', 'model_type': family, 'head_dim': head_dim,
             'native_eager_source_sha256': EAGER_SHA256, 'short_native_threshold': SHORT_NATIVE_THRESHOLD,
             'calls': 0, 'short_native_calls': 0, 'optimized_calls': 0,
             'fused_scale_mask_cast_calls': 0, 'alias_softmax_calls': 0,
             'triton_block_size': BLOCK_SIZE, 'triton_num_warps': NUM_WARPS,
             'enable_fp_fusion': False, 'cuda_validation': 'Requires real registered model probe'}

    def fused(module_, query, key, value, attention_mask, scaling, dropout=0.0, **kwargs):
        _inference_guard(module_, dropout, kwargs)
        stats['calls'] += 1
        if query.shape[-2] <= SHORT_NATIVE_THRESHOLD:
            stats['short_native_calls'] += 1
            return native(module_, query, key, value, attention_mask, scaling, dropout=dropout, **kwargs)
        if query.shape[-1] != head_dim or float(scaling) != head_dim ** -0.5:
            raise ValueError('Head dimension/scaling differ from registered config')
        stats['optimized_calls'] += 1
        key_states = module.repeat_kv(key, module_.num_key_value_groups)
        value_states = module.repeat_kv(value, module_.num_key_value_groups)
        scores = torch.matmul(query, key_states.transpose(2, 3))
        scores_fp32 = scale_mask_to_fp32(scores, attention_mask, scaling)
        del scores
        stats['fused_scale_mask_cast_calls'] += 1
        torch.softmax(scores_fp32, dim=-1, out=scores_fp32)
        stats['alias_softmax_calls'] += 1
        weights = scores_fp32.to(query.dtype)
        del scores_fp32
        weights = torch.nn.functional.dropout(weights, p=dropout, training=module_.training)
        output = torch.matmul(weights, value_states)
        del weights
        return output.transpose(1, 2).contiguous(), None

    module.eager_attention_forward = fused
    model.config._attn_implementation = 'eager'
    return stats


def validate_lower_right_mask(mask, query, key):
    """Semantic check for the registered batch1 no-padding workload, probe only.

    Checks the actual supplied mask, not cache length. May synchronize/copy
    tensors and must not be hidden inside performance measurements.
    """
    import torch
    q, k = query.shape[-2], key.shape[-2]
    if q > k:
        raise ValueError('Query length cannot exceed complete KV length')
    from torch.nn.attention.bias import CausalBias, CausalVariant
    if isinstance(mask, CausalBias):
        if mask.variant != CausalVariant.LOWER_RIGHT or (mask.seq_len_q, mask.seq_len_kv) != (q, k):
            raise ValueError('CausalBias does not describe complete lower-right Q/K dimensions')
        return
    if mask is None:
        if q != k and q != 1:
            raise ValueError('Rectangular continuation requires the HF explicit causal mask')
        return
    if mask.ndim != 4 or mask.shape[0] != 1 or mask.shape[1] not in (1, query.shape[1]) or tuple(mask.shape[-2:]) != (q, k):
        raise ValueError('Unexpected mask dimensions; no padding/batch/window generalization allowed')
    expected = torch.arange(k, device=mask.device)[None, :] <= (torch.arange(q, device=mask.device)[:, None] + k - q)
    if mask.dtype == torch.bool:
        valid = torch.equal(mask, expected.expand_as(mask))
    else:
        expected = expected.expand_as(mask)
        allowed_zero = torch.all(mask[expected] == 0)
        blocked = mask[~expected]
        blocked_negative = torch.all(torch.isneginf(blocked) | (blocked == torch.finfo(mask.dtype).min))
        valid = bool(allowed_zero and blocked_negative)
    if not valid:
        raise ValueError('Mask is not exactly the registered no-padding lower-right causal pattern')


def install_lower_right_sdpa(model, *, validate_masks=True):
    """Separate optimized control with correct lower-right continuation alignment.

    ``validate_masks=False`` is permitted ONLY for a frozen no-padding batch1
    workload whose actual masks were independently checked in a probe. It
    removes semantic diagnostics, not computation. HF-created masks remain
    allocated and therefore part of memory measurements. Backend dispatch may
    select Flash/efficient/math and MUST be observed separately, never assumed.
    """
    import torch
    from torch.nn.attention.bias import causal_lower_right, CausalBias
    from transformers.modeling_utils import AttentionInterface
    from transformers.integrations.sdpa_attention import sdpa_attention_forward
    family, module, head_dim = _model_module(model)
    _source_guard(sdpa_attention_forward, SDPA_SHA256)
    _source_guard(CausalBias._dispatch, CAUSAL_DISPATCH_SHA256)
    native = module.eager_attention_forward
    original_interface = module.ALL_ATTENTION_FUNCTIONS
    _INSTALLED[family] = (module, native, original_interface, model.config._attn_implementation)
    stats = {'mode': 'sdpa_lower_right', 'model_type': family, 'head_dim': head_dim,
             'native_sdpa_source_sha256': SDPA_SHA256, 'causal_dispatch_source_sha256': CAUSAL_DISPATCH_SHA256,
             'calls': 0, 'prefill_calls': 0, 'continuation_calls': 0, 'semantic_mask_checks': 0,
             'validate_masks': bool(validate_masks), 'batch_size_contract': 1, 'padding_contract': 'none',
             'mask_allocation': 'Native HF mask construction retained, not removed from memory scope',
             'backend_claim': 'Auto dispatch; actual kernels require separate probe',
             'gqa_policy': 'Enable only when query heads differ from KV heads', 'gqa_calls': 0,
             'observed_qkv_shapes': []}

    def lower_right(module_, query, key, value, attention_mask, dropout=0.0, scaling=None,
                    is_causal=None, position_bias=None, **kwargs):
        _inference_guard(module_, dropout, kwargs)
        if position_bias is not None or is_causal is False:
            raise ValueError('Only decoder causal attention without position-bias override supported')
        if query.ndim != 4 or key.ndim != 4 or value.ndim != 4 or query.shape[0] != 1:
            raise ValueError('Only batch1, four-dimensional attention tensors supported')
        q, k = query.shape[-2], key.shape[-2]
        if q > k or key.shape != value.shape or query.shape[-1] != head_dim or key.shape[-1] != head_dim:
            raise ValueError('Unexpected complete KV/head dimensions')
        if query.shape[1] % key.shape[1] or scaling is None or float(scaling) != head_dim ** -0.5:
            raise ValueError('Invalid GQA ratio or scaling')
        if validate_masks:
            validate_lower_right_mask(attention_mask, query, key)
            stats['semantic_mask_checks'] += 1
        stats['calls'] += 1
        stats['gqa_calls'] += int(query.shape[1] != key.shape[1])
        stats['prefill_calls' if q == k else 'continuation_calls'] += 1
        shape = [list(query.shape), list(key.shape), list(value.shape)]
        if shape not in stats['observed_qkv_shapes']:
            stats['observed_qkv_shapes'].append(shape)
        if q == k:
            output = torch.nn.functional.scaled_dot_product_attention(
                query, key, value, attn_mask=None, dropout_p=0.0, is_causal=True,
                scale=scaling, enable_gqa=query.shape[1] != key.shape[1])
        else:
            output = torch.nn.functional.scaled_dot_product_attention(
                query, key, value, attn_mask=causal_lower_right(q, k), dropout_p=0.0,
                is_causal=False, scale=scaling, enable_gqa=query.shape[1] != key.shape[1])
        return output.transpose(1, 2).contiguous(), None

    # Instance-local interface, so stock global registry remains unmodified.
    interface = AttentionInterface()
    interface['sdpa'] = lower_right
    module.ALL_ATTENTION_FUNCTIONS = interface
    model.config._attn_implementation = 'sdpa'
    return stats
