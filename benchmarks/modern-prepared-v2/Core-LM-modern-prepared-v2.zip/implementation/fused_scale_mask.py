"""Multi-model Triton scale+mask+cast candidate; CUDA model equality is a separate gate.

Full scores/mask, BF16 rounding after both operations, FP32 output. No CPU
fallback, autotuning, approximate softmax, or implicit mask/precision changes.
"""
import triton
import triton.language as tl

EXPECTED_TRITON = '3.7.1'
BLOCK_SIZE = 1024
NUM_WARPS = 4


@triton.jit
def _scale_mask_fp32_kernel(
    Scores, Mask, Output, N: tl.constexpr,
    H: tl.constexpr, Q: tl.constexpr, K: tl.constexpr,
    MS0: tl.constexpr, MS1: tl.constexpr, MS2: tl.constexpr, MS3: tl.constexpr,
    HAS_MASK: tl.constexpr, SCALE: tl.constexpr, BLOCK: tl.constexpr,
):
    i = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    valid = i < N
    original = tl.load(Scores + i, mask=valid, other=0).to(tl.float32)
    scale_fp32 = tl.full((), SCALE, tl.float32)
    if HAS_MASK:
        if MS0 == 0 and MS1 == 0 and MS2 == K and MS3 == 1:
            # Common full causal mask shared over batch/heads, exact indexing.
            mask_offset = i % (Q * K)
        else:
            b = i // (H * Q * K)
            h = (i // (Q * K)) % H
            q = (i // K) % Q
            k = i % K
            mask_offset = b * MS0 + h * MS1 + q * MS2 + k * MS3
        additive_mask = tl.load(Mask + mask_offset, mask=valid, other=0).to(tl.float32)
        # Inline PTX fixes arithmetic and rounding boundaries. Triton can
        # otherwise fold FP32 multiply + BF16 cast into native BF16 fma(+0)
        # even with enable_fp_fusion=False; that is not this registered path.
        result = tl.inline_asm_elementwise(
            asm="""{
                .reg .f32 scaled, rounded_scaled, masked;
                .reg .b16 scaled_bf16, masked_bf16;
                mul.rn.f32 scaled, $1, $3;
                cvt.rn.bf16.f32 scaled_bf16, scaled;
                cvt.f32.bf16 rounded_scaled, scaled_bf16;
                add.rn.f32 masked, rounded_scaled, $2;
                cvt.rn.bf16.f32 masked_bf16, masked;
                cvt.f32.bf16 $0, masked_bf16;
            }""", constraints="=f,f,f,f", args=[original, additive_mask, scale_fp32],
            dtype=tl.float32, is_pure=True, pack=1,
        )
    else:
        result = tl.inline_asm_elementwise(
            asm="""{
                .reg .f32 scaled;
                .reg .b16 scaled_bf16;
                mul.rn.f32 scaled, $1, $2;
                cvt.rn.bf16.f32 scaled_bf16, scaled;
                cvt.f32.bf16 $0, scaled_bf16;
            }""", constraints="=f,f,f", args=[original, scale_fp32],
            dtype=tl.float32, is_pure=True, pack=1,
        )
    tl.store(Output + i, result, mask=valid)


def mask_broadcast_strides(score_shape, mask_shape, mask_strides):
    """Pure-Python validation, preserving arbitrary nonnegative mask strides."""
    if len(score_shape) != 4 or len(mask_shape) != 4 or len(mask_strides) != 4:
        raise ValueError('Expected 4D [batch, heads, queries, keys] scores and mask')
    if any(int(size) <= 0 for size in score_shape):
        raise ValueError('Empty scores are not supported')
    if any(int(size) not in (1, int(target)) for size,target in zip(mask_shape,score_shape)):
        raise ValueError('Mask cannot broadcast to complete score shape')
    if any(int(stride) < 0 for stride in mask_strides):
        raise ValueError('Negative mask strides are not supported')
    return tuple(0 if int(size) == 1 else int(stride) for size,stride in zip(mask_shape,mask_strides))


def scale_mask_to_fp32(scores, attention_mask, scaling):
    import torch
    if triton.__version__ != EXPECTED_TRITON:
        raise RuntimeError('Pinned Triton 3.7.1 required')
    if torch.is_grad_enabled():
        raise RuntimeError('Fused candidate requires inference/no_grad mode')
    if scores.device.type != 'cuda' or scores.dtype != torch.bfloat16 or scores.ndim != 4 or not scores.is_contiguous():
        raise ValueError('Fused candidate requires private contiguous 4D CUDA BF16 scores')
    if float(scaling) not in (64 ** -0.5, 128 ** -0.5):
        raise ValueError('Only registered head dimensions 64/128 scaling supported')
    if scores.numel() <= 0 or scores.numel() >= 2**31:
        raise ValueError('Unsupported score indexing range')
    strides = (0,0,0,0)
    if attention_mask is not None:
        if attention_mask.device != scores.device or attention_mask.dtype != torch.bfloat16:
            raise ValueError('Fused candidate requires same-device BF16 additive mask; no narrowing fallback')
        strides = mask_broadcast_strides(scores.shape, attention_mask.shape, attention_mask.stride())
    output = torch.empty(scores.shape, dtype=torch.float32, device=scores.device)
    _scale_mask_fp32_kernel[(triton.cdiv(scores.numel(), BLOCK_SIZE),)](
        scores, attention_mask if attention_mask is not None else scores, output,
        N=scores.numel(), H=scores.shape[1], Q=scores.shape[2], K=scores.shape[3],
        MS0=strides[0], MS1=strides[1], MS2=strides[2], MS3=strides[3],
        HAS_MASK=attention_mask is not None, SCALE=float(scaling), BLOCK=BLOCK_SIZE,
        num_warps=NUM_WARPS, enable_fp_fusion=False,
    )
    return output
