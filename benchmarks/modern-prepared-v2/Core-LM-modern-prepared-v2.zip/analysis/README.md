# Six-pair exploratory matrix analysis

Run after retaining the complete matrix and matching probe directories:

```
python analysis/analyze_matrix.py --root MATRIX_ROOT --probe-root PROBE_ROOT --out NEW_ANALYSIS_DIRECTORY
```

NumPy required; no torch/GPU needed. The explicit probe-root option allows relocated archives. Raw reference paths in worker metrics are relative and must retain their original layout. Analyzer never edits evidence; output must not exist. Exit0 means audited completeness, not a favorable result; exit2 means incomplete/failed audit. Both still emit JSON and CSV including negative and unsupported comparisons.

Fixed primary: Qwen0.5 / 4096, stock SDPA versus fused. Ratios are always candidate/baseline. Six fresh process medians, paired log t df5 critical2.015048; deterministic Python Random seed20261113,100000 resamples, upper nearest-rank95th percentile. Every observed ratio must be ≤1 and both upper bounds <1 for no-slowdown. Secondary estimates are exploratory and unadjusted; no universal win claim or cross-model NLL ranking.

Trace audit function copied unchanged from frozen V2 `analyze_confirm.py` SHA256352d2ff8bb3f4e71e746d142f50c333059089247b37c3b7fba8fff5b188d83b7; only minimal dependencies retained. Checks include PID namespaces, external process contamination, query status, artifact digests, sample order/max gap/maxima and before-start/after-exit coverage. Sampling distributions remain in complete JSON. These are observed NVML maxima, never continuous physical maxima. Allocator counters are full-lifetime and source/phase checks reject resets.

Raw arrays/digests, repeat-to-memory references, finite outputs, full KV, registered tokens, source/runtime/probe identity and actual randomized order are audited. Eager/fused byte equality is mandatory; a failed modern SDPA legacy compatibility threshold alone does not discard speed or memory. Comparison scalar NLL/difference values originate from the benchmark's streamed FP64 comparison and are retained with identity/finite/threshold checks; this analyzer does not independently recompute them. The separate eight-window quality sweep is NOT certified by this matrix-only analyzer and needs separate review before any expanded quality claim.

Generated tests are isolated in tests/test_matrix_analysis.py, not empirical benchmark outcomes. No GPU run was performed to develop this analyzer. CSV reports repeat0 numeric comparison values (same-arm deterministic payload checks cover repeats); JSON retains all six.
