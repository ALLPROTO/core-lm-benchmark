#!/usr/bin/env python3
"""Independent CPU raw-logit numerical audit. Never performance evidence."""
import argparse, hashlib, json, math
from pathlib import Path
import numpy as np
MODES=('eager','fused','sdpa','sdpa_lower_right')
PAIRS=(('eager','fused'),('sdpa','fused'),('sdpa_lower_right','fused'),('eager','sdpa'),('eager','sdpa_lower_right'),('sdpa','sdpa_lower_right'))

def read(p): return json.loads(Path(p).read_text())
def digest(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def require(c,s):
    if not c:raise ValueError(s)
def compute(arrays_a,arrays_b,targets):
    count=elements=agree=0; maxerr=abssum=squares=0.;nll=[0.,0.];exact=True
    for a,b,ts in zip(arrays_a,arrays_b,targets,strict=True):
        require(a.shape==b.shape and a.ndim==2 and a.shape[0]==len(ts),'Shape/target mismatch')
        require(a.dtype==b.dtype==np.float32,'Expected FP32 saved logits')
        exact=exact and a.tobytes()==b.tobytes()
        for x,y,t in zip(a,b,ts,strict=True):
            vals=[x.astype(np.float64),y.astype(np.float64)]
            require(all(np.isfinite(v).all() for v in vals),'Nonfinite logits')
            require(type(t) is int and 0<=t<len(x),'Invalid target')
            d=vals[1]-vals[0]; maxerr=max(maxerr,float(np.abs(d).max()));abssum+=float(np.abs(d).sum());squares+=float((d*d).sum());elements+=d.size
            count+=1;agree+=int(np.argmax(vals[0])==np.argmax(vals[1]))
            for i,v in enumerate(vals):
                mx=float(v.max());nll[i]+=float(mx+np.log(np.exp(v-mx).sum())-v[t])
    require(count>0,'Empty comparison')
    delta=(nll[1]-nll[0])/count
    return {'scored_tokens':count,'top1_agreement':agree/count,'exact_quality_gate':exact,'raw_files_byte_identical':exact,
        'max_abs_logit_difference':maxerr,'mean_abs_logit_difference':abssum/elements,'rms_logit_difference':math.sqrt(squares/elements),
        'mean_nll_fp64':[v/count for v in nll],'delta_nll_fp64':delta,'abs_delta_nll_fp64':abs(delta)}

def close_values(actual,expected,path=''):
    if isinstance(actual,list):
        require(isinstance(expected,list) and len(actual)==len(expected),'Length mismatch '+path)
        for i,(a,b) in enumerate(zip(actual,expected)):close_values(a,b,f'{path}/{i}')
    elif isinstance(actual,bool) or isinstance(actual,int):require(actual==expected,'Mismatch '+path)
    else: require(math.isfinite(expected) and abs(actual-expected)<=1e-10,'Numeric disagreement '+path)

def load_arm(root,stage,model,length,mode,reg,plan):
    d=root/stage/f'{model}-L{length}'/f'repeat-0-{mode}';m=read(d/'metrics.json');td=read(d/'tokens.json')
    require(read(d/'process-exit.json')['returncode']==0,'Worker failed')
    require((m['model'],m['length'],m['mode'],m['purpose'],m['repeat'])==(model,length,mode,stage,0),'Wrong identity')
    require(m['runtime']==reg['runtime'] and m['registry_sha256']==digest(root/'registry.json'),'Runtime/registry mismatch')
    require(m['model_revision']==reg['models'][model]['revision'],'Revision mismatch')
    require(m['source_sha256']==plan['source_sha256']['benchmark_matrix.py'],'Worker source mismatch')
    for name,h in plan['source_sha256'].items():require(digest(root/'harness'/name)==h,'Frozen source changed '+name)
    tp=root/reg['models'][model]['token_file'];require(digest(tp)==reg['models'][model]['token_file_sha256'],'Token file changed')
    token_doc=read(tp);ids=token_doc['token_ids'];require(len(ids)==4096 and m['token_ids_sha256']==token_doc['sha256'],'Wrong token identity')
    require(hashlib.sha256(np.asarray(ids,dtype='<u4').tobytes()).hexdigest()==token_doc['sha256'],'Token payload changed')
    expected=[ids[s:s+2048] for s in range(0,1024,128)] if stage=='quality' else [ids[-length:]]
    names=['quality-offset-'+str(s) for s in range(0,1024,128)] if stage=='quality' else ['suffix-'+str(length)]
    require(len(td['blocks'])==len(expected) and len(m['rounds'])==1 and len(m['rounds'][0]['blocks'])==len(expected),'Wrong block count')
    positions=[];arrays=[];targets=[];raw=[]
    for i,(t,b,seq,name) in enumerate(zip(td['blocks'],m['rounds'][0]['blocks'],expected,names,strict=True)):
        require(t['block']==b['block']==name and t['tokens']==seq and t['targets']==seq[-128:],'Wrong window/targets')
        if stage=='quality':positions.extend(range(i*128+1920,i*128+2048))
        p=d/b['raw_logits_file'];require(digest(p)==b['raw_logits_sha256'],'Raw file changed')
        a=np.load(p,mmap_mode='r',allow_pickle=False)
        require(a.dtype==np.float32 and a.shape==(128,m['vocab_size']),'Raw shape/type')
        require(hashlib.sha256(a.view(np.uint8)).hexdigest()==b['raw_payload_sha256'],'Raw payload changed')
        arrays.append(a);targets.append(t['targets']);raw.append({'file':str(p),'sha256':digest(p)})
    if stage=='quality':require(positions==list(range(1920,2944)) and len(set(positions))==1024,'Distinct quality target positions changed')
    if stage in ('quality','probe'):
        sem=m['diagnostic_semantics'];require(sem['pass'],'Semantic probe failed')
        size=2048 if stage=='quality' else length
        for phase,q,k in [('prefill',size-129,size-129),('continuation',128,size-1)]:
            require(any(x['phase']==phase and x['q'][-2]==q and x['k'][-2]==k and x['prefix_in_attention_verified'] and x['future_exclusion_verified'] for x in sem['records']),'Actual semantic dimensions absent')
    return {'arrays':arrays,'targets':targets,'raw':raw,'metadata':m,'positions':positions}

def audit_root(root,probe_root=None):
    root=Path(root);plan=read(root/'run-plan.json');reg=read(root/'registry.json');stage='memory' if plan['stage']=='matrix' else plan['stage']
    require(stage in ('probe','quality','memory'),'Unsupported stage')
    # Always enumerate the full required study, retaining not-run cells explicitly.
    cells=[]
    for model in ('qwen05','qwen15','smol17'):
        for length in ([2048] if stage=='quality' else [512,2048,4096]):
            arms={};records={}
            for mode in MODES:
                try:
                    a=load_arm(root,stage,model,length,mode,reg,plan);arms[mode]=a
                    if stage=='memory':
                        require(probe_root is not None,'Memory audit needs --probe-root for semantic evidence')
                        pr=Path(probe_root);pp=read(pr/'run-plan.json');pg=read(pr/'registry.json');pa=load_arm(pr,'probe',model,length,mode,pg,pp)
                        require(pa['metadata']['gpu_uuid']==a['metadata']['gpu_uuid'],'Probe GPU changed')
                        require(pa['metadata']['token_ids_sha256']==a['metadata']['token_ids_sha256'] and pa['metadata']['runtime']==a['metadata']['runtime'] and pa['metadata']['model_revision']==a['metadata']['model_revision'],'Probe inputs/runtime/revision changed')
                        for f in ('benchmark_matrix.py','attention_adapters.py','fused_scale_mask.py'):require(pp['source_sha256'][f]==plan['source_sha256'][f],'Probe source changed')
                    records[mode]={'pass':True,'raw':a['raw'],'target_positions':a['positions']}
                except (ValueError,KeyError,OSError,TypeError,IndexError) as e:records[mode]={'pass':False,'error':str(e)}
            comparisons=[]
            for base,cand in PAIRS:
                r={'baseline':base,'candidate':cand,'pass':False,'errors':[]}
                try:
                    require(all(x in arms for x in (base,cand)),'Missing raw arm')
                    a,b=arms[base],arms[cand];require(a['targets']==b['targets'],'Different true targets')
                    n=compute(a['arrays'],b['arrays'],a['targets']);r['recomputed']=n
                    cp=root/stage/f'{model}-L{length}'/f'comparison-0-{base}-vs-{cand}.json';old=read(cp)
                    require((old['model'],old['length'],old['baseline_mode'],old['candidate_mode'])==(model,length,base,cand),'Comparison identity mismatch')
                    for k,v in n.items():
                        if k!='abs_delta_nll_fp64':close_values(v,old[k],k)
                    # NPY byte equality is separately verified from numeric payload equality.
                    files_equal=all(x['sha256']==y['sha256'] for x,y in zip(a['raw'],b['raw']))
                    require(old['raw_files_byte_identical']==files_equal,'Raw file byte comparison differs')
                    require(all(records[x]['pass'] for x in (base,cand)),'Arm metadata/semantic audit failed')
                    if cand=='fused':
                        require('eager' in arms,'Missing exact reference')
                        eager=arms['eager'];require(all(x.tobytes()==y.tobytes() for x,y in zip(eager['arrays'],b['arrays'],strict=True)),'Fused exact eager contract failed')
                    r['pass']=True;r['reported_legacy_compatibility_gate']=old['legacy_compatibility_gate']
                except (ValueError,KeyError,OSError,TypeError,IndexError) as e:r['errors'].append(str(e))
                comparisons.append(r)
            cells.append({'model':model,'length':length,'arms':records,'comparisons':comparisons})
    return {'root':str(root),'stage':stage,'cells':cells,'pass':all(all(a['pass'] for a in c['arms'].values()) and all(x['pass'] for x in c['comparisons']) for c in cells)}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,action='append',required=True);p.add_argument('--probe-root',type=Path);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    require(not a.out.exists(),'Never overwrite evidence/output');results=[]
    for root in a.root:
        try:results.append(audit_root(root,a.probe_root))
        except (ValueError,KeyError,OSError,TypeError) as e:results.append({'root':str(root),'pass':False,'error':str(e)})
    output={'schema':'independent-raw-numerics-v1','source_sha256':digest(__file__),'tolerance':1e-10,'results':results,'pass':all(x['pass'] for x in results),'scope':'CPU recomputation only. No performance claims, no cross-model NLL ranking. SDPA compatibility failure is retained, not a semantic failure.'}
    a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(output,indent=2,allow_nan=False)+'\n');return 0 if output['pass'] else 2
if __name__=='__main__':raise SystemExit(main())
