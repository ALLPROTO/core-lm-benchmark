#!/usr/bin/env python3
"""Read-only six-pair exploratory matrix audit. No generated empirical evidence.

Ratios always candidate / baseline. NVML is sampled, not continuous physical peak.
"""
import argparse, ast, csv, hashlib, json, math, random, statistics
from pathlib import Path
import numpy as np
from physical_audit_legacy import audit_physical

MODES=('eager','fused','sdpa','sdpa_lower_right')
COMPARISONS=(('eager','fused'),('sdpa','fused'),('sdpa_lower_right','fused'),('eager','sdpa'),('eager','sdpa_lower_right'),('sdpa','sdpa_lower_right'))
PRIMARY={'model':'qwen05','length':4096,'comparison':['sdpa','fused']}
N=6; T=2.015048; DRAWS=100000; SEED=20261113

def read(p): return json.loads(Path(p).read_text())
def digest(p):
    with Path(p).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def require(ok,msg):
    if not ok: raise ValueError(msg)
def speed_statistics(ratios):
    require(len(ratios)==N,'Exactly six independent pairs required')
    require(all(math.isfinite(x) and x>0 for x in ratios),'Invalid ratio')
    logs=list(map(math.log,ratios)); mean=statistics.mean(logs); se=statistics.stdev(logs)/math.sqrt(N)
    rng=random.Random(SEED)
    boot=sorted(sum(logs[rng.randrange(N)] for _ in range(N))/N for _ in range(DRAWS))
    upper=math.exp(mean+T*se); lower=math.exp(mean-T*se); bu=math.exp(boot[math.ceil(.95*DRAWS)-1])
    passed=all(x<=1 for x in ratios) and upper<1 and bu<1
    return {'paired_process_median_ratios':ratios,'independent_pairs':N,'geometric_mean_ratio':math.exp(mean),
        'range':[min(ratios),max(ratios)],'one_sided_95pct_t_lower_ratio':lower,'one_sided_95pct_t_upper_ratio':upper,
        'paired_bootstrap_95pct_upper_ratio':bu,'bootstrap_seed':SEED,'bootstrap_draws':DRAWS,'t_df':5,'t_critical':T,
        'all_observed_pair_medians_no_slower':all(x<=1 for x in ratios),'no_slowdown_pass':passed,
        'status':'PASS' if passed else 'SLOWDOWN' if lower>1 else 'INCONCLUSIVE',
        'scope':'Exploratory paired-log t assumption; bootstrap is sensitivity only, not independent evidence. Inner rounds are not independent.'}

def source_audit(root,plan):
    require(plan['stage']=='matrix' and plan['repeats']==N,'Wrong stage/repeats')
    require(plan['peak_resets'] is False and plan['cache_clearing'] is False,'Reset/cache clearing forbidden')
    require(plan['primary_cell']==PRIMARY,'Primary changed')
    require(digest(root/'registry.json')==plan['registry_sha256'],'Registry hash changed')
    for section,folder in [('source_sha256','harness'),('instrumentation_sha256','instrumentation')]:
        require(bool(plan.get(section)),'Missing frozen '+section)
        for name,h in plan[section].items():
            p=root/folder/name; require(digest(p)==h,'Frozen source changed: '+name)
            if p.suffix=='.py':
                calls={n.func.attr for n in ast.walk(ast.parse(p.read_text())) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)}
                require(not calls & {'empty_cache','reset_peak_memory_stats','reset_max_memory_allocated','reset_max_memory_cached'},'Allocator reset/clear')

def raw_audit(directory,block,model,mode,length,seen=None):
    seen=set() if seen is None else seen
    if 'raw_logits_file' not in block:
        p=(directory/block['raw_reference_metrics']).resolve()
        require(p not in seen,'Raw-reference cycle'); seen.add(p)
        ref=read(p); require((ref['model'],ref['mode'],ref['length'],ref['purpose'],ref['repeat'])==(model,mode,length,'memory',0),'Wrong raw reference')
        target=next(x for x in ref['rounds'][0]['blocks'] if x['block']==block['block'])
        require(block['matches_memory_run_raw_payload'] and block['raw_payload_sha256']==target['raw_payload_sha256'],'Same-arm raw mismatch')
        return raw_audit(p.parent,target,model,mode,length,seen)
    p=directory/block['raw_logits_file']; require(digest(p)==block['raw_logits_sha256'],'Raw file changed')
    arr=np.load(p,mmap_mode='r',allow_pickle=False)
    require(arr.dtype==np.float32 and arr.ndim==2 and arr.shape[0]==128,'Wrong raw dtype/shape')
    require(hashlib.sha256(arr.view(np.uint8)).hexdigest()==block['raw_payload_sha256'],'Raw payload changed')
    require(bool(np.isfinite(arr).all()),'Nonfinite outputs')
    return block['raw_payload_sha256']

def audit_run(root,plan,reg,model,length,mode,purpose,repeat,probe_root):
    d=root/purpose/f'{model}-L{length}'/f'repeat-{repeat}-{mode}'
    result={'directory':str(d),'errors':[],'available':False}
    try:
        m=read(d/'metrics.json'); result['available']=True; result['metrics']=m
        require(read(d/'process-exit.json')['returncode']==0,'Failed worker')
        require((m['model'],m['length'],m['mode'],m['purpose'],m['repeat'])==(model,length,mode,purpose,repeat),'Wrong run identity')
        require(m['runtime']==reg['runtime'] and m['registry_sha256']==plan['registry_sha256'],'Runtime/registry mismatch')
        require(m['source_sha256']==plan['source_sha256']['benchmark_matrix.py'],'Worker source mismatch')
        require(m['model_revision']==reg['models'][model]['revision'],'Revision mismatch')
        require(m['batch_size']==1 and m['weights_dtype']==m['cache_dtype']=='bfloat16','Precision/batch changed')
        require(m['deterministic_algorithms'] and not m['tf32'] and m['seed']==0,'Numeric settings changed')
        require(m['cuda'] and '+cpu' not in m['runtime']['torch'] and m['model_storage']['bytes_by_device'] and all(k.startswith('cuda') for k in m['model_storage']['bytes_by_device']),'Offloaded/CPU model')
        require(len(m['warmups'])==2 and len(m['rounds'])==(9 if purpose=='latency' else 1),'Wrong rounds/warmups')
        td=read(d/'tokens.json'); frozen=read(root/reg['models'][model]['token_file'])
        require(digest(root/reg['models'][model]['token_file'])==reg['models'][model]['token_file_sha256'],'Frozen tokens changed')
        ids=frozen['token_ids'][-length:]
        require(len(td['blocks'])==1 and td['blocks'][0]['tokens']==ids and td['blocks'][0]['targets']==ids[-128:],'Inputs/targets changed')
        times=[]; hashes=[]
        for rnd in m['rounds']:
            require(len(rnd['blocks'])==1,'Wrong workload blocks')
            b=rnd['blocks'][0]; c=b['cache_after_continuation']; layers=m['num_hidden_layers']
            require(b['prefix_cache_lengths']==[length-129]*layers and c['lengths']==[length-1]*layers,'Prefix truncated')
            expected=layers*2*m['num_key_value_heads']*(length-1)*m['head_dim']*2
            require(c['unique_storage_bytes']==expected==b['expected_kv_storage_bytes'] and all(k.startswith('cuda') for k in c['bytes_by_device']),'Changed/offloaded KV')
            require(math.isfinite(b['seconds']) and b['seconds']>0 and abs(b['seconds']-rnd['workload_seconds'])<1e-9,'Invalid latency')
            times.append(b['seconds']); hashes.append(raw_audit(d,b,model,mode,length))
        require(len(set(hashes))==1,'Nondeterministic outputs')
        result['raw_payload_sha256']=hashes[0]; result['median_seconds']=statistics.median(times)
        require(abs(result['median_seconds']-m['latency_median_workload_seconds'])<1e-10,'Wrong reported median')
        events=[json.loads(x) for x in (d/'phases.jsonl').read_text().splitlines()]
        result['first_wall_ns']=events[0]['wall_time_ns']
        require(events[-1]['phase']=='worker_results_complete','Incomplete phases')
        peaks=[(x['memory']['cumulative_peak_allocated_bytes'],x['memory']['cumulative_peak_reserved_bytes']) for x in events if 'memory' in x]
        require(all(a[0]<=b[0] and a[1]<=b[1] for a,b in zip(peaks,peaks[1:])),'Peak counter decreased')
        if purpose=='memory':
            p=audit_physical(d/'physical'); result['physical']=p
            require(p['uuid'].removeprefix('GPU-')==m['gpu_uuid'].removeprefix('GPU-'),'Wrong observed UUID')
            require(p['event_max_allocated_bytes']<=m['session_memory']['cumulative_peak_allocated_bytes'] and p['event_max_reserved_bytes']<=m['session_memory']['cumulative_peak_reserved_bytes'],'Late peak omitted')
            result['sampling']=read(d/'physical'/'summary.json')['sampling']
        else: require(not (d/'physical').exists(),'Latency contaminated by sampler')
        require(probe_root is not None,'Missing probe root')
        pr=probe_root/'probe'/f'{model}-L{length}'/f'repeat-0-{mode}'
        pm=read(pr/'metrics.json'); pp=read(probe_root/'run-plan.json')
        require(read(pr/'process-exit.json')['returncode']==0 and pm['diagnostic_semantics']['pass'],'Probe failed')
        require((pm['model'],pm['length'],pm['mode'])==(model,length,mode),'Wrong probe cell')
        require(pm['gpu_uuid']==m['gpu_uuid'] and pm['runtime']==m['runtime'] and pm['model_revision']==m['model_revision'] and pm['token_ids_sha256']==m['token_ids_sha256'],'Probe environment/inputs mismatch')
        for f in ('benchmark_matrix.py','attention_adapters.py','fused_scale_mask.py'):
            require(digest(probe_root/'harness'/f)==plan['source_sha256'][f]==pp['source_sha256'][f],'Probe source mismatch')
        require(all(any(r['phase']==phase and r['q'][-2]==q and r['k'][-2]==k and r['prefix_in_attention_verified'] and r['future_exclusion_verified'] for r in pm['diagnostic_semantics']['records']) for phase,q,k in [('prefill',length-129,length-129),('continuation',128,length-1)]),'Probe actual dimensions/semantics absent')
        if mode=='fused': require(read(pr.parent/'comparison-0-eager-vs-fused.json')['exact_quality_gate'],'Probe fused exact failed')
    except (ValueError,KeyError,TypeError,OSError,StopIteration,IndexError) as e: result['errors'].append(str(e))
    return result

def summarize_memory(pairs):
    out={}
    for name in ('device','process','allocated','reserved'):
        values=[]
        for a,b in pairs:
            if name in ('device','process'): values.append([r['physical'][name+'_max_bytes'] for r in (a,b)])
            else: values.append([r['metrics']['session_memory']['cumulative_peak_'+name+'_bytes'] for r in (a,b)])
        ratios=[b/a for a,b in values]
        out[name]={'paired_maxima_bytes':values,'ratios':ratios,'geometric_mean_ratio':math.exp(statistics.mean(map(math.log,ratios))),'range':[min(ratios),max(ratios)],'all_pairs_lower':all(r<1 for r in ratios)}
    return out

def analyze(root,probe_root=None):
    root=Path(root); plan=read(root/'run-plan.json'); reg=read(root/'registry.json'); global_errors=[]
    try: source_audit(root,plan)
    except (ValueError,KeyError,OSError) as e: global_errors.append(str(e))
    probe_root=Path(probe_root or plan['probe_root']) if probe_root or plan.get('probe_root') else None
    cells=[]; environment=None
    for cell in plan['cells']:
        model,length=cell['model'],cell['length']; ck=f'{model}-L{length}'; errors=[]; runs={}
        for purpose in ('memory','latency'):
            orders=plan['pair_orders'][ck][purpose]
            try:
                require(len(orders)==6 and all(len(o)==4 and set(o)==set(MODES) for o in orders),'Wrong orders')
                require(all(sum(o.index(a)<o.index(b) for o in orders)==3 for a,b in COMPARISONS),'Unbalanced pairs')
            except (ValueError,KeyError) as e: errors.append(str(e))
            for i in range(N):
                block={}
                for mode in MODES:
                    r=audit_run(root,plan,reg,model,length,mode,purpose,i,probe_root); runs[(purpose,i,mode)]=r; block[mode]=r
                    if r.get('metrics'):
                        m=r['metrics']; env=[m.get(k) for k in ('runtime','python','numpy','cuda','gpu_uuid')]
                        if environment is None: environment=env
                        if env!=environment:r['errors'].append('Hardware/runtime changed')
                available=[x for x in MODES if 'first_wall_ns' in block[x]]
                if sorted(available,key=lambda x:block[x]['first_wall_ns']) != [x for x in orders[i] if x in available]: errors.append(f'Actual order mismatch {purpose}/{i}')
        comparisons=[]
        for base,cand in COMPARISONS:
            problems=list(global_errors)+list(errors); timing=[]; memory=[]; numeric=[]
            for i in range(N):
                for purpose in ('memory','latency'):
                    pair=[runs[purpose,i,m] for m in (base,cand)]
                    problems.extend(f'{purpose}/{i}/{m}: {e}' for m,r in zip((base,cand),pair) for e in r['errors'])
                    if purpose=='latency' and all('median_seconds' in r for r in pair): timing.append({'repeat':i,'medians_seconds':[r['median_seconds'] for r in pair],'ratio':pair[1]['median_seconds']/pair[0]['median_seconds']})
                    if purpose=='memory' and all('physical' in r for r in pair): memory.append(pair)
                p=root/'memory'/ck/f'comparison-{i}-{base}-vs-{cand}.json'
                if p.exists():
                    n=read(p); numeric.append(n)
                    try:
                        require((n['model'],n['length'],n['baseline_mode'],n['candidate_mode'])==(model,length,base,cand),'Numeric comparison identity mismatch')
                        require(n['scored_tokens']==128 and len(n['raw_checks'])==1,'Wrong numeric scope')
                        ar,br=runs['memory',i,base],runs['memory',i,cand]
                        exact=bool(ar.get('raw_payload_sha256') and ar.get('raw_payload_sha256')==br.get('raw_payload_sha256'))
                        require(n['exact_quality_gate']==exact==n['raw_files_byte_identical'],'Numeric exact gate inconsistent with audited raw payloads')
                        require(all(math.isfinite(n[k]) for k in ('top1_agreement','max_abs_logit_difference','mean_abs_logit_difference','rms_logit_difference','delta_nll_fp64','delta_nll_fp32')),'Nonfinite numeric comparison')
                        require(n['legacy_compatibility_gate']==(n['top1_agreement']>=.99 and n['delta_nll_fp64']<=.01 and n['delta_nll_fp32']<=.01),'Legacy threshold changed')
                    except (ValueError,KeyError,TypeError) as e: problems.append(str(e))
                else: problems.append(f'Missing numeric comparison {i}')
                if cand=='fused':
                    a,b=runs['memory',i,'eager'],runs['memory',i,'fused']
                    if not a.get('raw_payload_sha256') or a.get('raw_payload_sha256')!=b.get('raw_payload_sha256'): problems.append(f'Fused exact gate failed/missing {i}')
            speed=speed_statistics([x['ratio'] for x in timing]) if len(timing)==N else None
            mem=summarize_memory(memory) if len(memory)==N else None
            valid=not problems
            comparisons.append({'baseline':base,'candidate':cand,'primary':model=='qwen05' and length==4096 and (base,cand)==('sdpa','fused'),
                'audit_pass':valid,'status':'AUDITED' if valid else 'FAILED_OR_INCOMPLETE','errors':problems,
                'speed':speed,'timing_pairs':timing,'memory':mem,'numeric_comparisons':numeric,
                'no_slowdown_demonstrated':bool(valid and speed and speed['no_slowdown_pass']),
                'observed_memory_and_speed_win':bool(valid and speed and speed['no_slowdown_pass'] and mem and mem['device']['all_pairs_lower'] and mem['process']['all_pairs_lower']),
                'legacy_compatibility_failure_does_not_exclude_performance':True})
        # Full audited records retain failed/partial metrics and actual sampling-gap distributions.
        cells.append({'model':model,'length':length,'comparisons':comparisons,'runs':{f'{p}/{i}/{m}':r for (p,i,m),r in runs.items()}})
    return {'schema':'modern-matrix-analysis-v1','primary':PRIMARY,'global_errors':global_errors,'cells':cells,
        'execution_summary':read(root/'summary.json') if (root/'summary.json').exists() else {'status':'missing/incomplete'},
        'continuous_physical_peak_certified':False,'separate_quality_sweep_audited':False,'numeric_audit_scope':'Comparison scalar values are read from frozen harness results; independently verified exact payload hashes, finite fields, identity and unchanged thresholds. FP64 NLL is not independently recomputed here. Separate quality sweep must be reviewed before broad exactness claims.','scope':'Six-pair exploratory matrix; no universal win, no cross-tokenizer NLL ranking; compatibility is not quality accuracy. Cached JIT, median of nine after two warmups.',
        'analyzer_sha256':digest(__file__),'physical_helper_sha256':digest(Path(__file__).with_name('physical_audit_legacy.py'))}

def write_outputs(result,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=False)
    (out/'analysis.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    fields=['model','length','baseline','candidate','primary','status','no_slowdown_demonstrated','speed_gm','speed_t_upper','speed_bootstrap_upper','device_gm','process_gm','allocated_gm','reserved_gm','top1_agreement_repeat0','max_abs_logit_difference_repeat0','delta_nll_fp64_repeat0','abs_delta_nll_fp64_repeat0','legacy_compatibility_repeat0','errors']
    with (out/'comparisons.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for cell in result['cells']:
            for c in cell['comparisons']:
                s=c['speed'] or {};m=c['memory'] or {}
                row={k:c[k] for k in ('baseline','candidate','primary','status','no_slowdown_demonstrated')}
                row.update(model=cell['model'],length=cell['length'],speed_gm=s.get('geometric_mean_ratio'),speed_t_upper=s.get('one_sided_95pct_t_upper_ratio'),speed_bootstrap_upper=s.get('paired_bootstrap_95pct_upper_ratio'),errors='; '.join(c['errors']))
                n=c.get('numeric_comparisons',[{}])[0] if c.get('numeric_comparisons') else {}
                row.update(top1_agreement_repeat0=n.get('top1_agreement'),max_abs_logit_difference_repeat0=n.get('max_abs_logit_difference'),delta_nll_fp64_repeat0=n.get('delta_nll_fp64'),abs_delta_nll_fp64_repeat0=abs(n['delta_nll_fp64']) if 'delta_nll_fp64' in n else None,legacy_compatibility_repeat0=n.get('legacy_compatibility_gate'))
                row.update({k+'_gm':m.get(k,{}).get('geometric_mean_ratio') for k in ('device','process','allocated','reserved')});w.writerow(row)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--probe-root',type=Path);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();r=analyze(a.root,a.probe_root);write_outputs(r,a.out)
    return 0 if not r['global_errors'] and all(c['audit_pass'] for cell in r['cells'] for c in cell['comparisons']) else 2
if __name__=='__main__':raise SystemExit(main())
