"""Unchanged audit_physical copied from frozen V2 analyze_confirm.py.
Only dependencies and the physical audit are retained; no legacy benchmark CLI.
Original source SHA256 is recorded in README. Read-only observer trace audit.
"""
import hashlib,json
from pathlib import Path

def read(path):return json.loads(Path(path).read_text())
def digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def require(ok,message):
    if not ok:raise ValueError(message)

def audit_physical(directory):
    directory = Path(directory)
    summary = read(directory / 'summary.json')
    s = summary['sampling']
    aliases = set(s['pid_namespace_aliases'])
    require(summary['status'] == 'completed' and summary['child_returncode'] == 0,
            'Physical observer/worker did not complete')
    require(summary['child_pid'] in aliases, 'Missing verified target PID')
    previous = first = last = None
    device_peak = process_peak = 0
    count = matched_count = 0
    max_gap = 0.0
    external = set()
    for line in (directory / 'samples.jsonl').open():
        row = json.loads(line)
        require(row['sample_index'] == count, 'Sample sequence mismatch')
        count += 1
        start = row['start_ns']
        first = start if first is None else first
        if previous is not None:
            require(start >= previous, 'Sampling clock moved backwards')
            max_gap = max(max_gap, (start - previous) / 1e6)
        previous = last = start
        rows = []
        for query in ('device', 'compute', 'graphics'):
            q = row[query]
            require(q['ok'], 'NVML query failed')
            require(start <= q['start_ns'] <= q['end_ns'] <= row['end_ns'], 'Invalid query timestamps')
            if query != 'device':
                rows.extend(q.get('value', []))
        external.update(x['pid'] for x in rows if x['pid'] not in aliases)
        matched = [x['used_bytes'] for x in rows if x['pid'] in aliases and x['used_bytes'] is not None]
        matched_value = max(matched) if matched else None
        require(matched_value == row['matched_target_used_bytes'], 'Incorrect process mapping')
        if matched:
            matched_count += 1
            process_peak = max(process_peak, matched_value)
        used = row['device']['value']['used']
        require(isinstance(used, int) and 0 <= used < 2**63, 'Invalid device usage')
        device_peak = max(device_peak, used)
    require(not external and not s['initial_gpu_pids'], 'External/unmapped GPU process observed')
    require(count == s['sample_count'] and matched_count == s['target_sample_count'] > 0,
            'Sampling counts disagree')
    require(device_peak == s['sampled_device_max_bytes'] and
            process_peak == s['sampled_matched_process_max_bytes'], 'Sampled maxima disagree')
    require(abs(max_gap - s['actual_start_gap_ms']['max']) < 1e-9, 'Gap maximum disagrees')
    require(first < summary['gate_release_ns'] and last > summary['child_exit_observed_ns'],
            'Observer failed lifetime endpoint coverage')
    for name, meta in summary['artifacts'].items():
        p = directory / name
        require(p.stat().st_size == meta['bytes'] and digest(p) == meta['sha256'],
                'Observer artifact changed: ' + name)
    require(summary['coverage_checks']['worker_start_sentinel_before_cuda_init'],
            'Worker was already CUDA-initialized at its entry marker')
    require(summary['coverage_checks']['worker_normal_finish_sentinel'], 'Missing normal finish')
    phase_allocated = phase_reserved = 0
    for event in summary['worker_events']:
        for device in event.get('torch_state', {}).get('devices', []):
            phase_allocated = max(phase_allocated, device['allocated_peak_bytes'])
            phase_reserved = max(phase_reserved, device['reserved_peak_bytes'])
    return {'device_max_bytes': device_peak, 'process_max_bytes': process_peak,
            'sample_count': count, 'requested_interval_ms': summary['requested_interval_ms'],
            'max_observed_gap_ms': max_gap, 'uuid': summary['gpu_uuid'],
            'event_max_allocated_bytes': phase_allocated, 'event_max_reserved_bytes': phase_reserved,
            'metric': 'Observed sampled NVML maxima, not exact continuous physical peaks'}


