"""Resolve immutable public assets and tokenize registered real public text. No model inference."""
import concurrent.futures,hashlib,json,pathlib,sys,urllib.request,time
ROOT=pathlib.Path(__file__).parent
class pins:
 DATASET_REPOSITORY='Salesforce/wikitext'
 DATASET_REVISION='b08601e04326c79dfdd32d625aee71d232d685c3'
 DATASET_LICENSE='CC BY-SA 3.0 and GFDL'
 DATASET_FILES={'validation':{'path':'wikitext-2-raw-v1/validation-00000-of-00001.parquet','sha256':'204929b7ff9d6184953f867dedb860e40aa69c078fc1e54b3baaa8fb28511c4c','bytes':657209}}
def registered_blocks(tokenizer,parquet_path):
 import pyarrow.parquet as parquet
 import numpy as np
 text='\n\n'.join(parquet.read_table(parquet_path,columns=['text']).column('text').to_pylist())
 previous=tokenizer.model_max_length;tokenizer.model_max_length=sys.maxsize
 try:ids=tokenizer(text,add_special_tokens=False,return_attention_mask=False,return_token_type_ids=False)['input_ids']
 finally:tokenizer.model_max_length=previous
 selected=ids[64*512:72*512]
 assert len(selected)==4096
 return [selected[i:i+512] for i in range(0,4096,512)],hashlib.sha256(np.asarray(selected,dtype='<u4').tobytes()).hexdigest()
from transformers import AutoTokenizer
models=json.loads((ROOT/'models-resolved.json').read_text());(ROOT/'inputs').mkdir(exist_ok=True)
def fetch(args):
 url,p=args
 if p.exists():return
 for attempt in range(3):
  try:b=urllib.request.urlopen(url,timeout=90).read();p.write_bytes(b);return
  except Exception:
   if attempt==2:raise
   time.sleep(1+attempt)
requests=[]
for m in models:
 d=ROOT/'asset-metadata'/m['alias']; info=json.loads((d/'model-info.json').read_text())
 names=[x['rfilename'] for x in info['siblings'] if x['rfilename'] in {'config.json','generation_config.json','merges.txt','tokenizer.json','tokenizer_config.json','vocab.json','special_tokens_map.json','LICENSE','README.md'}]
 for name in names:requests.append((f"https://huggingface.co/{m['repository']}/resolve/{m['revision']}/{name}",d/name))
corpus=ROOT/'inputs'/'public-validation.parquet';requests.append((f"https://huggingface.co/datasets/{pins.DATASET_REPOSITORY}/resolve/{pins.DATASET_REVISION}/{pins.DATASET_FILES['validation']['path']}",corpus))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(fetch,requests))
assert hashlib.sha256(corpus.read_bytes()).hexdigest()==pins.DATASET_FILES['validation']['sha256']
tok=AutoTokenizer.from_pretrained(ROOT/'asset-metadata/qwen05',local_files_only=True)
blocks,digest=registered_blocks(tok,corpus);qids=sum(blocks,[])
assert digest=='1bb36c91d441379596361ae779ca0542c85457e9902a290a6ab6945cb2513453'
excerpt=tok.decode(qids,skip_special_tokens=False,clean_up_tokenization_spaces=False)
assert tok(excerpt,add_special_tokens=False)['input_ids']==qids,'Qwen excerpt roundtrip changed registered inputs'
textbytes=excerpt.encode('utf-8');textsha=hashlib.sha256(textbytes).hexdigest();(ROOT/'inputs/public-excerpt.txt').write_bytes(textbytes)
registry={'schema':'real-public-modern-attention-matrix-v1','runtime':{'torch':'2.13.0+cu130','transformers':'5.14.1','triton':'3.7.1'},'lengths':[512,2048,4096],'modes':['eager','fused','sdpa','sdpa_lower_right'],'primary_cell':{'model':'qwen05','length':4096,'comparison':['sdpa','fused']},'models':{},'dataset':{'repository':pins.DATASET_REPOSITORY,'revision':pins.DATASET_REVISION,**pins.DATASET_FILES['validation'],'license':pins.DATASET_LICENSE},'excerpt':{'path':'inputs/public-excerpt.txt','sha256':textsha,'bytes':len(textbytes),'qwen_public_blocks':list(range(64,72))},'repeats':6,'warmups':2,'latency_rounds':9,'randomization_seed':20261113,'quality_windows':{'length':2048,'starts':[128*i for i in range(8)],'scored_targets_per_window':128}}
for m in models:
 alias=m['alias'];d=ROOT/'asset-metadata'/alias;tokenizer=AutoTokenizer.from_pretrained(d,local_files_only=True)
 full=tokenizer(excerpt,add_special_tokens=False,return_attention_mask=False,return_token_type_ids=False)['input_ids'];assert len(full)>=4096,(alias,len(full))
 ids=full[-4096:];import numpy as np
 tdigest=hashlib.sha256(np.asarray(ids,dtype='<u4').tobytes()).hexdigest()
 if alias in ('qwen05','qwen15'):assert tdigest==digest,(alias,tdigest)
 source={'dataset_repository':pins.DATASET_REPOSITORY,'dataset_revision':pins.DATASET_REVISION,'validation_sha256':pins.DATASET_FILES['validation']['sha256'],'qwen_public_blocks':list(range(64,72)),'excerpt_sha256':textsha,'selection':'suffix4096 of model-specific tokenization of the same registered public text','retokenized_full_count':len(full),'add_special_tokens':False,'clean_up_tokenization_spaces':False}
 tokenpath=ROOT/'inputs'/f'{alias}-tokens.json';tokenpath.write_text(json.dumps({'token_ids':ids,'sha256':tdigest,'source':source},indent=2)+'\n')
 assets=list(m['weights'])
 for p in sorted(d.iterdir()):
  if p.name=='model-info.json':continue
  b=p.read_bytes();assets.append({'path':p.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 registry['models'][alias]={k:v for k,v in m.items() if k not in ('weights','metadata_url','resolved_utc','alias')}
 registry['models'][alias].update(snapshot_path=f"../hf-cache/hub/models--{m['repository'].replace('/','--')}/snapshots/{m['revision']}",token_file=str(tokenpath.relative_to(ROOT)),token_file_sha256=hashlib.sha256(tokenpath.read_bytes()).hexdigest(),assets=assets,token_count=4096)
 print(alias,'fulltokens',len(full),'selected',len(ids),'token_sha256',tdigest,flush=True)
(ROOT/'registry.json').write_text(json.dumps(registry,indent=2)+'\n')
print('REGISTRY',hashlib.sha256((ROOT/'registry.json').read_bytes()).hexdigest(),flush=True)
