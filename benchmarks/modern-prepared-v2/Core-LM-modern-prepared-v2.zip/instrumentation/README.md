# Full-lifecycle GPU memory observations

## Result this instrumentation can and cannot establish

This adds complete **sampling coverage in time** around a fresh worker: before its
target program executes, throughout preparation/warmup/inference/output, and after
its process exits. It does **not** turn samples into an exact continuous physical
memory high-water mark. A 1 ms requested interval is not a 1 ms resolution guarantee.
Actual start-to-start gaps, query durations, individual query timestamps, failures,
and all raw values are retained. NVML may itself update accounting asynchronously.

Three separate metrics must retain their names:

1. **NVML sampled device/process maximum.** Observed maximum of returned values;
   an empirical lower bound for the corresponding reported footprint. Short
   transients or delayed driver updates may be missed. Device-wide figures include
   other processes and driver use. Process fields are available only when a PID
   identity can be verified and NVML supports the metric.
2. **PyTorch allocator high-water, allocated and reserved.** Allocator-maintained
   counters, not sampled reconstruction, provided the worker never resets them.
   These cover that allocator's tracked allocations, not all device physical memory.
   The backend is recorded; semantics differ for cudaMallocAsync. An optional
   allocator event snapshot supports inspection but is not a physical-memory trace.
3. **NVML accounting maxMemoryUsage.** If accounting was already enabled, preserve
   the driver-reported lifetime maximum allocated memory with UUID, PID, startTime,
   running/terminated state, and the raw observations. NVIDIA's field description
   is "Maximum total memory in bytes that was ever allocated by the process."
   This alone does not document event completeness, update frequency, treatment of
   all driver/context allocations, or exact physical residency. Do not relabel it
   as independently certified continuous physical peak.

Current GPU information supplied by the GPU operator: A100 UUID
`GPU-0e679649-68d3-959a-274d-90847a415bd4`, driver 595.71.05, torch 2.13.0+cu130,
Python 3.12, CUDA 12.8 CUPTI/nvcc available, no nsys. Accounting was Disabled.
An attempt by the operator to enable it returned **Insufficient Permissions**;
post-query remained Disabled. This code never enables accounting or changes any
GPU setting, and that denied operation must not be retried through another route.
These details are reported host observations, not checks run by the local author.

## Why two sampled peaks cannot prove 23% physical savings

Let N and O be native and optimized true peaks. To certify at least 23% reduction,
one needs `O <= 0.77 * N`. A valid optimized upper bound U and a native lower bound
L are sufficient if `U <= 0.77 * L`. Two observed maxima are only lower bounds;
`sampled_O <= 0.77 * sampled_N` does not imply the required inequality.

There is no generally valid missing-transient allowance obtained merely by
multiplying the largest sampling gap by a bandwidth figure. Allocation metadata,
resident mappings, lazy initialization, and driver overhead are not constrained by
that argument. An allocator cap covers only the allocator, and subtracting a
sampled "fixed overhead" is not a proof that all omitted overhead is constant.

A hardware-enforced whole-memory bound (for example a separately authorized,
properly isolated fixed-capacity GPU partition) could provide a conservative
upper bound, but would change the experimental environment and is not implemented
or authorized by this package. The trivial device-capacity upper bound is valid
for actual resident device memory but is far too loose for a several-GB workload
on an 80GB A100. Therefore this host's available measurements cannot certify the
user's literal exact continuous physical-peak requirement. Report this limit even
if sampled physical savings comfortably exceed 23%.

## Minimal host capability check

No package installs are needed if `pynvml` is already present. Run:

```sh
python capability_check.py --uuid GPU-0e679649-68d3-959a-274d-90847a415bd4 --output capability.json
```

It reads NVML memory, process lists, MIG, accounting mode/buffer/PIDs/stats, installed
package metadata, CUPTI libraries/version/exports, and nsys availability/help.
It does not import torch, create a CUDA context intentionally, or change settings.
`--no-driver` skips driver and CUPTI load calls for CPU-only smoke tests.

## Worker interface and launch

```python
from lifecycle_worker import start, phase, finish, enable_allocator_history
start()                         # First worker action, before torch import.
import torch
enable_allocator_history()      # No-op unless requested; before CUDA operations.
phase("model_preparation")
# Load/move model, warmups, and workload. Never reset allocator peaks/empty_cache.
phase("warmup_0")
phase("inference_round_0")
phase("raw_output_0")
finish()                        # Normal completion. atexit is recorded separately.
```

The functions are no-ops in ordinary unmonitored timing workers. Arbitrary phase
labels are accepted. Calls belong outside timed intervals. `phase` reads existing
CUDA allocator counters only after torch says CUDA is initialized; it does not
initialize CUDA, synchronize, empty caches, or reset peaks. Optional history uses
PyTorch's private `_record_memory_history` API with no stack contexts, and writes
a trusted-local pickle at the end. It reports errors, entry counts, and possible
ring truncation. A trace at the configured limit must not be called complete.

```sh
python lifecycle_monitor.py \
  --uuid GPU-0e679649-68d3-959a-274d-90847a415bd4 \
  --output results/native-memory/physical --interval-ms 1 \
  -- python benchmark_attention.py worker --repo REPO --out results/native-memory \
     --mode eager --workload concatenated4096 --purpose memory
```

The output directory must **not already exist**. The monitor puts its own directory
on the child's PYTHONPATH. It initializes NVML, samples a default 50 ms baseline,
starts a fresh standard-library-only gate process, samples while that gate is
held, then releases it to `exec` the actual command without changing PID. It keeps
sampling until process exit and for a default 250 ms tail. It captures both stdout
and stderr. The launched command must be the actual worker, not a launcher that
forks untracked GPU grandchildren. Use one fresh process per comparable arm.

Optional `--allocator-history` records a separate allocator snapshot. It is
deliberately optional because profiling has overhead. `--history-max-entries`
controls the event buffer. Do not load a snapshot pickle from an untrusted source.

## Outputs and auditing

- `run-start.json`: unique run ID, exact command, hardware request, source hashes,
  sampling configuration and monotonic/wall-clock start sentinels.
- `gate-ready.json`: target PID and observed PID namespace aliases, recorded before
  the target program executes.
- `samples.jsonl`: every sample with device, compute-process, graphics-process
  values, separate begin/end timestamps for each non-atomic query, and errors.
- `worker-events.jsonl`: run-tagged start, named phases, finish and atexit sentinels,
  torch allocator counters/backend/device UUID when already initialized.
- `accounting.json`: mode, baseline IDs, target pre-exec records, all observations
  and identity groups. Disabled/unsupported is retained, not replaced by zero.
- `worker.stdout.log`, `worker.stderr.log`: exact worker output.
- `allocator-snapshot.pickle`: optional, PyTorch allocator trace only.
- `summary.json`: coverage checks, observed maxima, actual gaps, worker exit code,
  contamination/PID-match warnings, full artifact hashes, and explicit false
  fields for exact continuous physical certification and physical savings proof.

Verify that worker device UUID matches the selected NVML UUID; that every required
phase is present; that worker finish and exit-zero are recorded; that the observer
sampled before target execution and after process exit; that no counter reset
exists in the source; and that known external GPU users are absent. Process-PID
matching uses only actual observed namespace aliases. It does not infer a host PID
from a singleton new GPU process or an assumed offset. Container PID mapping may
therefore leave process memory unavailable while device memory remains measured.
The absence of external PIDs in samples does not prove there were no short-lived
external users; operational isolation must be established separately. Queries for
compute, graphics, and device memory are not simultaneous snapshots.

MIG and MPS state are preserved but not silently normalized. Under MIG, MPS,
multi-process workers, PID reuse, or unknown namespace mapping, audit the scope
before interpreting any process figure. Accounting identity requires UUID, PID,
startTime consistency and the terminated record; circular-buffer retention and
pre-existing PID records can invalidate a comparison.

## Speed comparison

Use separate fresh workers with the same mode, model, data, seeds, warmup, and
CUDA synchronization boundaries, **without** the monitor, allocator history, or
profilers. Alternate/randomize arm order, retain every repeat, and report the
latency distribution/paired ratios and uncertainty. Memory-run durations are not
evidence of no slowdown. Both arms must use identical timing instrumentation.
Separate profiling and speed runs establish two observations for the same code
configuration, not a theorem that every execution is always faster or smaller.

## CUPTI / Nsight scope

CUPTI allocation/activity tracing or Nsight Systems CUDA memory tracing can reveal
short allocation lifetimes missed by polling and explain allocations outside the
PyTorch allocator. Neither should automatically be described as all physical VRAM
residency. Runtime/driver callbacks must account for async pools, VMM create/map/
unmap/release, context lifetime and dropped activity records, and distinguish
logical allocation, committed backing and reserved address space. Callback entry
is not necessarily the instant the memory becomes resident. A correct trace of
visible CUDA allocations still may omit driver/context or another process's use.
No unverified CUPTI tracer is included, and CUDA 12.8 CUPTI with a CUDA 13 runtime
must have its compatibility and coverage checked before use. This extra profiler
cannot by itself resolve the unavailable exact physical-memory proof, so it is not
a prerequisite to the lighter and honestly labeled measurements above.

Reference supplied/verified by the coordinating research worker:
https://docs.nvidia.com/deploy/nvml-api/latest/api/structnvmlAccountingStats__t.html

## Local validation

`python test_lifecycle.py -v` passes five CPU-only mocked-NVML tests: whole-lifecycle
gating and post-exit coverage/gap reconstruction; accounting identity/termination
and external-process detection; failed worker tail capture; NVML failure before
launch; and unmonitored helper no-ops. `python -m py_compile *.py` passes.
These tests are harness checks, not GPU measurements. Real host NVML/CUDA behavior
and private PyTorch event-history APIs require a smoke run on the target GPU.
No existing/frozen evidence files were modified.
