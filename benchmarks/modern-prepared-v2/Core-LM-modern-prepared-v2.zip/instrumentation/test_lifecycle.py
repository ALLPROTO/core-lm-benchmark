"""CPU-only mocked NVML integration tests. No GPU evidence is produced."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).parent

FAKE_NVML = '''
import json, os
from pathlib import Path
from types import SimpleNamespace as NS
def state():
    p = Path(os.environ["FAKE_STATE"])
    return json.loads(p.read_text()) if p.exists() else {}
def nvmlInit():
    if os.environ.get("FAKE_INIT_FAIL"): raise RuntimeError("mock init failure")
def nvmlShutdown(): pass
def nvmlDeviceGetHandleByUUID(uuid): return uuid
def nvmlDeviceGetUUID(h): return h
def nvmlDeviceGetName(h): return "MOCK NO GPU"
def nvmlSystemGetNVMLVersion(): return "MOCK"
def nvmlSystemGetDriverVersion(): return "MOCK"
def nvmlDeviceGetMigMode(h): return (0,0)
def nvmlDeviceGetMPSComputeRunningProcesses(h): return []
def nvmlDeviceGetAccountingMode(h): return int(os.environ.get("FAKE_ACCOUNTING", "0"))
def nvmlDeviceGetAccountingPids(h): return [state()["pid"]] if state() else []
def nvmlDeviceGetAccountingStats(h,pid):
    s=state()
    if pid != s.get("pid"): raise RuntimeError("not found")
    return NS(maxMemoryUsage=345678901,startTime=777,isRunning=int(s.get("alive",False)),time=50)
def nvmlDeviceGetMemoryInfo(h):
    s=state(); used=s.get("used",0) if s.get("alive") else 0
    return NS(total=80000000000,used=used,free=80000000000-used)
def nvmlDeviceGetComputeRunningProcesses(h):
    s=state(); rows=[NS(pid=s["pid"],usedGpuMemory=s["used"])] if s.get("alive") else []
    if os.environ.get("FAKE_EXTERNAL"): rows += [NS(pid=999999, usedGpuMemory=123456)]
    return rows
def nvmlDeviceGetGraphicsRunningProcesses(h): return []
'''

FAKE_WORKER = '''
from lifecycle_worker import start, phase, finish
start()
import json, os, time
from pathlib import Path
p = Path(os.environ["FAKE_STATE"])
def save(value):
    tmp=Path(str(p)+".tmp"); tmp.write_text(json.dumps(value)); tmp.replace(p)
phase("model_preparation")
save(dict(pid=os.getpid(),alive=True,used=345678901))
time.sleep(.04)
phase("warmup_0")
save(dict(pid=os.getpid(),alive=True,used=123456789))
time.sleep(.04)
phase("inference_round_0")
save(dict(pid=os.getpid(),alive=False,used=0))
if os.environ.get("FAKE_WORKER_FAIL"): raise SystemExit(7)
finish()
'''


class LifecycleTests(unittest.TestCase):
    def run_monitor(self, overrides=None):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        base = Path(directory.name)
        (base / "pynvml.py").write_text(FAKE_NVML)
        (base / "worker.py").write_text(FAKE_WORKER)
        env = dict(os.environ, PYTHONPATH=str(base), FAKE_STATE=str(base / "state.json"))
        env.update(overrides or {})
        proc = subprocess.run([sys.executable, str(ROOT / "lifecycle_monitor.py"), "--uuid", "GPU-MOCK",
            "--output", str(base / "result"), "--baseline-ms", "5", "--post-exit-ms", "10",
            "--interval-ms", "1", "--", sys.executable, str(base / "worker.py")],
            env=env, capture_output=True, text=True, timeout=15)
        summary = json.loads((base / "result" / "summary.json").read_text())
        return proc, summary, base

    def test_full_lifecycle(self):
        proc, summary, base = self.run_monitor()
        self.assertEqual(proc.returncode, 0, proc.stderr + proc.stdout)
        checks = summary["coverage_checks"]
        for field in ("observer_sampled_before_target_exec", "observer_sampled_after_process_exit",
                      "worker_start_sentinel_before_cuda_init", "worker_normal_finish_sentinel", "worker_exit_zero"):
            self.assertTrue(checks[field], field)
        self.assertFalse(checks["exact_continuous_physical_peak"])
        self.assertFalse(summary["physical_savings_certified"])
        sampling = summary["sampling"]
        self.assertEqual(sampling["sampled_matched_process_max_bytes"], 345678901)
        self.assertEqual(sampling["sampled_device_max_bytes"], 345678901)
        self.assertEqual(sampling["observed_external_or_unmapped_pids"], [])
        rows = [json.loads(line) for line in (base / "result" / "samples.jsonl").read_text().splitlines()]
        gap = max(b["start_ns"] - a["start_ns"] for a, b in zip(rows, rows[1:])) / 1e6
        self.assertEqual(gap, sampling["actual_start_gap_ms"]["max"])
        self.assertTrue(all(row["end_ns"] >= row["start_ns"] for row in rows))

    def test_accounting_and_contamination(self):
        proc, summary, base = self.run_monitor({"FAKE_ACCOUNTING": "1", "FAKE_EXTERNAL": "1"})
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertIn(999999, summary["sampling"]["observed_external_or_unmapped_pids"])
        accounting = json.loads((base / "result" / "accounting.json").read_text())
        self.assertFalse(accounting["settings_changed"])
        own = [group for group in accounting["identity_groups"] if group["namespace_pid_matches_worker"]]
        self.assertEqual(len(own), 1)
        self.assertEqual(own[0]["maxMemoryUsage"], 345678901)
        self.assertTrue(own[0]["observed_terminated"])
        self.assertEqual(own[0]["startTime"], 777)

    def test_worker_failure_keeps_tail(self):
        proc, summary, base = self.run_monitor({"FAKE_WORKER_FAIL": "1"})
        self.assertEqual(proc.returncode, 1)
        self.assertEqual(summary["child_returncode"], 7)
        self.assertTrue(summary["coverage_checks"]["observer_sampled_after_process_exit"])
        self.assertFalse(summary["coverage_checks"]["worker_normal_finish_sentinel"])

    def test_no_nvml_fails_before_target_launch(self):
        proc, summary, base = self.run_monitor({"FAKE_INIT_FAIL": "1"})
        self.assertEqual(proc.returncode, 1)
        self.assertNotIn("child_pid", summary)
        self.assertFalse((base / "state.json").exists())

    def test_helpers_noop_without_monitor(self):
        env = {k: v for k, v in os.environ.items() if not k.startswith("PHYSICAL_PEAK_")}
        env["PYTHONPATH"] = str(ROOT)
        proc = subprocess.run([sys.executable, "-c", "from lifecycle_worker import *; start(); phase('anything'); enable_allocator_history(); finish()"], env=env, capture_output=True)
        self.assertEqual(proc.returncode, 0, proc.stderr)


if __name__ == "__main__":
    unittest.main()
