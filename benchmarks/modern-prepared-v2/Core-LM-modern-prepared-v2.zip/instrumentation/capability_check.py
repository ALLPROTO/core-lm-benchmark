#!/usr/bin/env python3
"""Read-only capabilities; no CUDA context, installs, or accounting setting changes.

Run this on the GPU host first. `--no-driver` permits a CPU-only syntax smoke test.
"""
import argparse
import ctypes
import ctypes.util
import glob
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import time


def safe(call):
    try:
        return {"ok": True, "value": call()}
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}


def plain(value):
    if isinstance(value, bytes):
        return value.decode(errors="replace")
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, (tuple, list)):
        return [plain(v) for v in value]
    if hasattr(value, "_fields_"):
        return {field[0]: plain(getattr(value, field[0])) for field in value._fields_}
    if hasattr(value, "__dict__"):
        return {k: plain(v) for k, v in vars(value).items() if not k.startswith("_")}
    return str(value)


def command(args, timeout=15):
    proc = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    return {"command": args, "returncode": proc.returncode,
            "stdout": proc.stdout[-32000:], "stderr": proc.stderr[-8000:]}


def accounting_probe(nv, handle):
    result = {}
    for name, args in [("nvmlDeviceGetAccountingMode", (handle,)),
                       ("nvmlDeviceGetAccountingBufferSize", (handle,)),
                       ("nvmlDeviceGetAccountingPids", (handle,))]:
        result[name] = safe(lambda name=name, args=args: plain(getattr(nv, name)(*args)))
    pids = result["nvmlDeviceGetAccountingPids"].get("value", [])
    result["stats"] = {str(pid): safe(lambda pid=pid: plain(nv.nvmlDeviceGetAccountingStats(handle, pid)))
                       for pid in pids[-128:]}
    result["no_settings_changed"] = True
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--uuid")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--no-driver", action="store_true")
    args = parser.parse_args()
    report = {"schema": "physical-peak-capability-v1", "time_ns": time.time_ns(),
              "python": platform.python_version(), "platform": platform.platform(),
              "pid": os.getpid(), "cuda_context_created_by_probe": False,
              "settings_changed": False, "packages": {}, "libraries": {}, "commands": {}}
    for dist in ("torch", "nvidia-ml-py", "pynvml", "nvidia-cuda-cupti-cu12", "nvidia-cuda-cupti"):
        report["packages"][dist] = safe(lambda dist=dist: importlib.metadata.version(dist))
    for name in ("pynvml", "torch"):
        spec = importlib.util.find_spec(name)
        report["packages"][name + "_module"] = spec.origin if spec else None
    report["profiler_files"] = sorted(set(glob.glob("/usr/local/cuda*/extras/CUPTI/lib64/libcupti.so*") +
        glob.glob("/usr/local/cuda*/targets/x86_64-linux/lib/libcupti.so*") +
        glob.glob("/usr/local/lib/python*/dist-packages/nvidia/cuda_cupti/lib/libcupti.so*") +
        glob.glob("/usr/local/lib/python*/site-packages/nvidia/cuda_cupti/lib/libcupti.so*")))
    for name in ("nvidia-ml", "cupti", "cuda"):
        report["libraries"][name] = ctypes.util.find_library(name)
    report["executables"] = {name: shutil.which(name) for name in ("nvidia-smi", "nsys", "nvprof", "nvcc")}
    if not args.no_driver:
        if report["executables"]["nvidia-smi"]:
            report["commands"]["nvidia-smi"] = safe(lambda: command(["nvidia-smi", "--query-gpu=uuid,name,driver_version,memory.total,mig.mode.current", "--format=csv,noheader"]))
        if report["executables"]["nsys"]:
            report["commands"]["nsys-version"] = safe(lambda: command(["nsys", "--version"]))
            h = safe(lambda: command(["nsys", "profile", "--help"]))
            if h.get("ok"):
                h["value"]["stdout"] = "\n".join(line for line in h["value"]["stdout"].splitlines()
                    if any(word in line.lower() for word in ("memory", "cuda", "sample", "trace")))
            report["commands"]["nsys-profile-relevant-help"] = h
        initialized = False
        try:
            import pynvml as nv
            nv.nvmlInit()
            initialized = True
            report["nvml_version"] = plain(nv.nvmlSystemGetNVMLVersion())
            handles = [nv.nvmlDeviceGetHandleByUUID(args.uuid)] if args.uuid else [
                nv.nvmlDeviceGetHandleByIndex(i) for i in range(nv.nvmlDeviceGetCount())]
            report["devices"] = []
            for handle in handles:
                device = {"uuid": plain(nv.nvmlDeviceGetUUID(handle)),
                          "name": plain(nv.nvmlDeviceGetName(handle)),
                          "memory": plain(nv.nvmlDeviceGetMemoryInfo(handle)),
                          "accounting": accounting_probe(nv, handle)}
                for name in ("nvmlDeviceGetMigMode", "nvmlDeviceGetComputeRunningProcesses",
                             "nvmlDeviceGetGraphicsRunningProcesses", "nvmlDeviceGetMPSComputeRunningProcesses"):
                    device[name] = safe(lambda name=name: plain(getattr(nv, name)(handle)))
                report["devices"].append(device)
        except Exception as exc:
            report["nvml_error"] = f"{type(exc).__name__}: {exc}"
        finally:
            if initialized:
                nv.nvmlShutdown()
        cupti_candidates = [report["libraries"]["cupti"]] + report["profiler_files"]
        report["cupti_load"] = []
        for candidate in [c for c in cupti_candidates if c][:4]:
            def load_cupti(candidate=candidate):
                lib = ctypes.CDLL(candidate)
                version = ctypes.c_uint32()
                fn = lib.cuptiGetVersion
                fn.argtypes = [ctypes.POINTER(ctypes.c_uint32)]
                fn.restype = ctypes.c_int
                status = fn(ctypes.byref(version))
                return {"path": candidate, "version_status": status, "version": version.value,
                        "exports": {name: hasattr(lib, name) for name in
                            ("cuptiActivityEnable", "cuptiActivityFlushAll", "cuptiActivityGetNumDroppedRecords", "cuptiSubscribe")}}
            report["cupti_load"].append(safe(load_cupti))
    else:
        report["driver_queries_skipped"] = True
    text = json.dumps(report, indent=2, allow_nan=False) + "\n"
    if args.output:
        args.output.write_text(text)
    print(text, end="")


if __name__ == "__main__":
    main()
