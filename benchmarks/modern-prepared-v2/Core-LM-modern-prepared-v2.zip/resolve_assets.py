"""Preparation-only public metadata resolution. No model benchmark run."""
import urllib.request,json,pathlib,hashlib,time
root=pathlib.Path(__file__).parent;out=root/'asset-metadata';out.mkdir(exist_ok=True)
models=[('qwen05','Qwen/Qwen2.5-0.5B','060db6499f32faf8b98477b0a26969ef7d8b9987'),('qwen15','Qwen/Qwen2.5-1.5B','8faed761d45a263340a0528343f099c05c9a4323'),('smol17','HuggingFaceTB/SmolLM2-1.7B','effd688a12921b4cc83e3312b6feb579f70f9c71')]
manifest=[]
for alias,repo,rev in models:
 url='https://huggingface.co/api/models/'+repo+('/revision/'+rev if rev else '')+'?blobs=true'
 raw=urllib.request.urlopen(url,timeout=60).read();j=json.loads(raw);rev=j['sha'];assert not j.get('gated') and not j.get('private')
 d=out/alias;d.mkdir(exist_ok=True);(d/'model-info.json').write_bytes(raw)
 cfg=urllib.request.urlopen(f'https://huggingface.co/{repo}/resolve/{rev}/config.json',timeout=60).read();(d/'config.json').write_bytes(cfg);config=json.loads(cfg)
 weights=[{'path':x['rfilename'],'bytes':x['size'],'sha256':x['lfs']['sha256']} for x in j['siblings'] if x['rfilename'].endswith('.safetensors') and '/' not in x['rfilename']]
 manifest.append({'alias':alias,'repository':repo,'revision':rev,'license':j.get('cardData',{}).get('license'),'config_sha256':hashlib.sha256(cfg).hexdigest(),'config_bytes':len(cfg),'model_type':config['model_type'],'max_position_embeddings':config['max_position_embeddings'],'weights':weights,'metadata_url':url,'resolved_utc':time.strftime('%FT%TZ',time.gmtime())})
 print(alias,rev,config['model_type'],config['hidden_size'],config['num_attention_heads'],config.get('num_key_value_heads'),config['max_position_embeddings'],sum(x['bytes'] for x in weights),flush=True)
(root/'models-resolved.json').write_text(json.dumps(manifest,indent=2)+'\n')
