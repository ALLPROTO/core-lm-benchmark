# Modern-baseline replication matrix, preregistered before GPU execution

## Purpose and scope

The prior A40 result established only a bit-exact eager-attention scratch-buffer optimization on one public regression: −27.36% observed-device memory and −17.82% paired median inference latency against native eager. It did not establish CoreLM codec effectiveness or superiority over modern attention kernels.

The new primary question is fixed in advance: **On Qwen2.5-0.5B, 4096-token workload, how does fused eager compare with untouched native Hugging Face SDPA?** A separately named lower-right SDPA control examines an optimized causal implementation without truncating the prefix. All other model/length cells are replication/exploratory results, not a search for a single marketable winner. Negative results and unsupported cases are retained and reported.

This is a new explicitly authorized multi-model study outside the old repository's frozen scientific boundary. The old maintained checkout, 26 frozen files, previous results and holdout/beacon remain unchanged. No frozen holdout/test split is executed.

## Inputs fixed before GPU

Three public, ungated pretrained models, all Apache-2.0:
- Qwen/Qwen2.5-0.5B at `060db6499f32faf8b98477b0a26969ef7d8b9987`.
- Qwen/Qwen2.5-1.5B at `8faed761d45a263340a0528343f099c05c9a4323`.
- HuggingFaceTB/SmolLM2-1.7B at `effd688a12921b4cc83e3312b6feb579f70f9c71`.

The registry contains immutable revision, config, asset sizes and SHA256 digests. Weight bytes must match before inference and be checked again after the experiment. Safetensors only; local-files-only workers; no remote model code. Runtime: PyTorch2.13.0+cu130, Transformers5.14.1, Triton3.7.1; A40 hardware/UUID and driver recorded, not mixed with earlier A100 runs.

Corpus: pinned Salesforce/wikitext validation, revision `b08601e04326c79dfdd32d625aee71d232d685c3`, parquet SHA256 `204929b7ff9d6184953f867dedb860e40aa69c078fc1e54b3baaa8fb28511c4c`. Licensed CC BY-SA3.0/GFDL; source https://huggingface.co/datasets/Salesforce/wikitext .

The same public text is decoded from already registered Qwen token blocks64–71, with `clean_up_tokenization_spaces=False`, and independently verified against the real parquet. Qwen re-tokenization must reproduce the old4096-token hash exactly. Each model tokenizes that same text without special tokens; the suffix4096 is frozen. Smol has4200 excerpt tokens, so104 leading tokens are omitted, not repeated or padded. Absolute NLL values from different tokenizers are not compared as model rankings.

## Workload matrix and quality sweep

Each model has lengths512,2048,4096, batch1. Each matrix cell uses suffix-L of its frozen4096 IDs, holding the final128 target token IDs constant within the model. Prefill has L−129 inputs; continuation has128 teacher-forced inputs, full L−1 KV positions remain on GPU. All128 full-vocabulary continuation logits are copied to CPU FP32. These are not128 sequential autoregressive decoding calls.

A separate quality-only sweep uses eight real windows of2048 tokens, starts0,128,...896 within the registered4096. Each has1919 prefill inputs and128 continuation inputs. This scores1024 distinct target positions1920..2943, while actually exercising the fused prefill path above its1536 threshold. No synthetic data, repeated/padded text or generated random pretrained-model metrics are permitted. Synthetic/tiny fixtures are isolated unit controls only.

## Arms

1. `eager`: untouched native model eager attention, numerical reference.
2. `fused`: guarded model-family adapter with original GEMMs and full KV; FP32 multiply→BF16 round→FP32 add→BF16 round→FP32 output in one Triton kernel, native FP32 softmax with private whole-buffer alias. Q≤1536 uses the original native eager path. Head64 and head128 are separately compiled and must independently pass real-model exact gates.
3. `sdpa`: stock Hugging Face/PyTorch SDPA, without monkeypatch, forced-math restrictions or artificial eager-mask construction. Normal native mask preparation remains inside timing.
4. `sdpa_lower_right`: explicitly separate experimental control. Native HF mask preparation is retained; square prefill uses implicit causal SDPA, rectangular continuation uses PyTorch `causal_lower_right(Q,K)` on complete K/V, with correct GQA. It is not represented as stock HF SDPA or as Flash without observed dispatch.

No weights/KV quantization, CPU offload, context truncation, allocator empty_cache or peak resets. No new software packages or kernels from unrecognized sources.

## Semantic and numerical gates

Before performance measurements, separate real-model probes must validate actual attention Q/K dimensions and causal relation, including all prefix positions and exclusion of future positions. Cache length alone is insufficient. A rectangular128-query/4095-key call must not be converted to ordinary upper-left `is_causal=True` or have K/V cropped to128. Probe-only instrumentation records actual backend operators and kernel names separately for prefill/continuation, dtype and GQA/repeat policy. `can_use_*` is not evidence of executed dispatch.

All arms require finite outputs and correct semantics. Fused→eager must additionally produce byte-identical complete saved continuation arrays for every model/length and the separate quality sweep. A fused exact failure is retained, not hidden by weaker tolerances. Stock SDPA remains in the performance table even if its correct BF16 arithmetic differs numerically.

For each non-eager arm report exact flag, top1 agreement, max/mean/RMS logit difference, true-target FP64 NLL and signed/absolute ΔNLL. Keep the previous ≥99% top1 / ΔNLL≤0.01 compatibility threshold unchanged and explicitly named. Failing it does not by itself prove semantic incorrectness or degraded language-model quality. Agreement is not accuracy. No thresholds change after inspecting model outcomes.

## Measurement and statistics

Memory and latency use different fresh processes. Six independent repetitions per model/length/arm per stage. Each four-arm block uses three seeded random permutations and their reversals, shuffled, so every pair is balanced3/3 in order. Fixed seed20261113; all schedules and source hashes saved before launch.

Each process has two same-arm warmups. Each latency process then runs nine complete identical workload rounds without NVML observer/profiler/semantic tensor checks. Its median is one observation; inner rounds are not independent samples. Timed scope includes input upload, complete prefill, continuation, retained full GPU KV/output and CPU FP32 copy. Model load, JIT, warmups, disk writes, hashing, NLL and inventory are recorded separately, not quietly counted as inference time. This is the fixed median-after-two-warmups metric, not a promise of thermal steady state or faster every-request latency. Shared compilation cache state and first-call costs must be explicit.

External NVML starts before CUDA initialization and continues beyond process exit. Record device and PID-attributed samples, actual timestamps, query errors, gap distribution and external-process contamination. Requested1ms polling is not continuous measurement. Report unadjusted observed maxima plus exact PyTorch allocated/reserved lifetime high-waters; driver allocations may lie outside allocator counters.

For each comparison show all six independent process ratios, geometric mean, descriptive range and one-sided95% paired-log t bounds (df5), plus seeded100000-draw paired bootstrap sensitivity bound. No pooling across models/lengths or treating the bootstrap as independent confirmation. Secondary matrix intervals are exploratory and not corrected into a universal win claim. Any claimed no-slowdown requires all observed paired medians≤1 and both prespecified upper bounds<1, zero slowdown margin. If an unexpectedly favorable claim warrants stronger confirmation, it requires a newly frozen independent12-pair run, not extra pairs appended until significant.

## Retention, budget and completion

Full raw first memory-run arrays per cell/arm, all quality-sweep arrays, and every unique unexpected array are retained. Repeated memory and all latency outputs are independently hashed against their same-arm raw reference; deterministic output failure is recorded and preserved. All observed memory traces, source snapshots, signed numerical differences, errors, backend diagnostics and per-round times remain available. Lossless archive hardlinks may deduplicate identical content, not delete evidence.

Latest verified balance: $19.26 from the original$20 allowance, with no GPU running at registration. Current A40 restart quote$0.59/hour, prior50GB temporary disk approximately$0.007/hour; existing untouched network storage approximately$0.015/hour. Initial study checkpoint$3, preserve at least$1 for orderly backup/shutdown, never exceed actual remaining authorization. Stop the temporary GPU after independently verifying an equivalent saved copy. Do not remove the older network volume or publish/merge externally.

All reports distinguish prior eager win, modern-baseline findings, regression coverage, known limitations and AI-assisted implementation from the user's separately demonstrated personal contribution.

## Pre-execution amendment (2026-11-12, no GPU model run yet)

A40 restart failed because Runpod had no capacity. The user approved an RTX A6000 48GB at the same $0.59/hour and initial $3 limit. All arms will be remeasured on one successfully allocated approved A40 or A6000, with fresh UUID and driver records; the actual GPU is fixed before the first probe, not selected after results. Prior A40/A100 absolute numbers are not pooled. Both GPUs use SM86, but identical architecture does not imply identical performance.

Add one explicitly secondary exploratory comparison: stock SDPA versus the already registered lower-right SDPA control. It asks whether correct lower-right specialization improves this fixed no-padding continuation, not whether fused eager wins. The primary Qwen0.5/L4096 fused-versus-stock-SDPA question and all workloads, gates, counts and thresholds remain unchanged. No GPU outcomes were available when adding this comparison. An interesting secondary result would need a separately frozen independent confirmation before a strong advantage claim.

Two pre-run instrumentation defects were fixed with real CPU integration tests: normalize the optional GPU- prefix in UUIDs, and preserve native SDPA function identity during diagnostic CausalBias dispatch. These fixes do not alter measured adapters or acceptance thresholds.
