# Reproducible modern-attention comparison

This package is an **experimental attention-memory study**, not proof that the
CoreLM KV codec beats modern production inference. Its candidate reduces eager
attention scratch buffers while preserving the original BF16 rounding steps.
Modern SDPA controls can be faster and use less memory. All outcomes must remain
in the final table.

## What is being compared

- Three immutable pretrained snapshots, two model families, GQA and MHA,
  head dimensions 64 and 128; model assets and SHA256 values in `registry.json`.
- One registered real WikiText validation excerpt, independently tokenized;
  batch 1 and lengths 512, 2048, 4096. No held-out/test corpus is used.
- `eager`, `fused`, untouched HF `sdpa`, separately labelled `sdpa_lower_right`.
- A fixed primary comparison: Qwen 0.5B / 4096 / stock SDPA versus fused.
  Other cells are exploratory replication coverage, not a winner-selection pool.
- Full prefill and one 128-input teacher-forced continuation, not 128 sequential
  autoregressive generation steps. Full weights and KV remain on GPU.

Read `PROTOCOL.md` before executing. It defines numerical gates, causal semantics,
measurement scope, repeated-process statistics and reporting limitations.

## Source layout

`implementation/attention_adapters.py` guards the pinned model-family source and
installs only the requested experimental adapter. `fused_scale_mask.py` uses one
Triton kernel with explicit FP32 arithmetic and BF16 round-to-nearest boundaries.
Its output is a private FP32 buffer; native softmax reuses that whole buffer.
Small queries use unchanged eager code. No KV/weight quantization or CPU offload.

`implementation/benchmark_matrix.py` runs fresh processes and records inputs,
full output arrays or independently checked hashes, full cache shape/storage,
actual adapter calls, numerical differences, and independent timing/memory runs.
Semantic probes inspect actual Q/K lengths and allowed causal positions. A
rectangular continuation never substitutes upper-left causal attention or drops
the prefix. Backend diagnostic traces are separate from measurements.

`instrumentation/` observes the worker lifetime with NVML and preserves allocator
high-water marks without reset or cache clearing. Requested polling frequency
is not achieved continuously; actual gaps and errors must be reported.

`analysis/` audits raw traces, identities and six paired process medians. Exit 0
means audit completeness, **not a favorable result**. A numerical compatibility
failure alone does not remove modern SDPA performance from the comparison.

## Reproduction sequence

1. Provision one CUDA BF16-capable GPU with adequate memory and temporary disk.
   Record its exact GPU/UUID, driver, tariff and runtime. Do not mix earlier
   A40/A100 numbers into a different GPU's matched baseline.
2. Extract this package as
   `/workspace/corelm-modern-study-20261112/prepared-matrix` and verify every
   `MANIFEST.json` entry. Execute `execution/bootstrap.sh` from that package.
   It installs the pinned official PyTorch/PyPI runtime, downloads only registered
   public assets, verifies every SHA256, and records capabilities and packages.
3. Run `bash prepared-matrix/execution/run_stages.sh probe`, then `quality`.
   Inspect failures and actual backend traces. No diagnostic time/peak is a
   performance result. A failed semantic gate invalidates that arm; a failed
   candidate exact gate must not be relaxed after seeing outputs.
4. Run `bash prepared-matrix/execution/run_stages.sh matrix`. It requires matching
   source/runtime/GPU/input probes, and a 1024-target exact quality gate for the
   candidate. A candidate failure is retained and does not exclude stock baselines.
5. Re-verify model assets without `--download`. Run the CPU analyzer with explicit
   `--root matrix --probe-root probe --out NEW_ANALYSIS_DIRECTORY`. Retain all
   numerical differences, negative outcomes, per-round times and sampled traces.
6. Save a complete evidence archive, verify every original path/hash on another
   computer, then stop the paid temporary GPU. Never delete unrelated storage.

Shared Triton compilation cache is intentional. Probe can compile first-use
kernels; measured inference uses the fixed median of nine rounds after two
same-arm warmups. This is neither a cold-start benchmark nor proof of thermal
steady state. Compilation/preparation costs must be described separately.

## Validation and claims

The local unit suite uses generated **unit fixtures only**. Passing CPU numerical,
mask, protocol and statistical tests or offline SM86 compilation is not CUDA
model evidence. Only the registered pretrained-model runs may support results.

Six paired fresh-process observations are not 54 independent samples. Secondary
intervals are exploratory; no pooling across models or lengths. Zero slowdown
requires every observed paired median ratio at most one and both prespecified
one-sided upper bounds below one. NVML maxima are sampled lower bounds, not a
mathematically continuous physical-memory maximum.

Model licenses are retained under `asset-metadata/`; WikiText is CC BY-SA 3.0 /
GFDL. Absolute NLL across different tokenizers is not a model quality ranking.
Implementation was AI-assisted. An interview account should distinguish measured
results, assistant-produced code, and the user's personally understood and
demonstrated contribution.
