"""Small generated arrays are unit controls only, not model evidence."""
import sys,unittest,math,tempfile
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'analysis'))
import audit_numerics as a
class NumericsTests(unittest.TestCase):
    def test_exact_uniform(self):
        x=np.zeros((2,3),np.float32);r=a.compute([x],[x],[[0,2]])
        self.assertTrue(r['exact_quality_gate']);self.assertEqual(r['top1_agreement'],1);self.assertAlmostEqual(r['mean_nll_fp64'][0],math.log(3))
    def test_known_difference(self):
        x=np.array([[0,0],[0,0]],np.float32);y=np.array([[0,1],[2,0]],np.float32)
        r=a.compute([x],[y],[[1,0]]);self.assertEqual(r['max_abs_logit_difference'],2);self.assertEqual(r['mean_abs_logit_difference'],.75);self.assertAlmostEqual(r['rms_logit_difference'],math.sqrt(1.25));self.assertEqual(r['top1_agreement'],.5)
        self.assertAlmostEqual(r['mean_nll_fp64'][1],(math.log1p(math.exp(-1))+math.log1p(math.exp(-2)))/2)
    def test_overflow_stability(self):
        x=np.array([[1000,999]],np.float32);r=a.compute([x],[x],[[0]]);self.assertAlmostEqual(r['mean_nll_fp64'][0],math.log1p(math.exp(-1)),places=12)
    def test_signed_zero_not_exact(self):
        x=np.zeros((1,2),np.float32);y=x.copy();y[0,0]=-0.;self.assertFalse(a.compute([x],[y],[[0]])['exact_quality_gate'])
    def test_nonfinite_rejected(self):
        x=np.array([[np.nan,0]],np.float32)
        with self.assertRaises(ValueError):a.compute([x],[x],[[0]])
    def test_invalid_target_rejected(self):
        x=np.zeros((1,2),np.float32)
        with self.assertRaises(ValueError):a.compute([x],[x],[[2]])
    def test_tolerance(self):
        a.close_values(.1,.1+5e-11)
        with self.assertRaises(ValueError):a.close_values(.1,.1+2e-10)
    def test_block_aggregation(self):
        x=np.zeros((1,2),np.float32);r=a.compute([x,x],[x,x],[[0],[1]]);self.assertEqual(r['scored_tokens'],2)
if __name__=='__main__':unittest.main()
