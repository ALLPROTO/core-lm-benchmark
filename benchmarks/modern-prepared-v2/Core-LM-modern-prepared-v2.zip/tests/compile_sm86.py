"""Offline compilation only, with no CUDA driver/GPU execution."""
import hashlib
import json
from pathlib import Path
import sys
import triton
from triton.compiler import ASTSource
from triton.backends.compiler import GPUTarget

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT/'implementation'))
from fused_scale_mask import _scale_mask_fp32_kernel

out = ROOT/'unit-controls'
out.mkdir(exist_ok=True)
records = []
for dim, masked in ((64,False),(64,True),(128,False),(128,True)):
    constants = dict(N=14*3967*3967,H=14,Q=3967,K=3967,MS0=0,MS1=0,MS2=3967,MS3=1,
                     HAS_MASK=masked,SCALE=dim**-.5,BLOCK=1024)
    signature = dict(Scores='*bf16',Mask='*bf16',Output='*fp32',**{k:'constexpr' for k in constants})
    source = ASTSource(_scale_mask_fp32_kernel, signature=signature, constexprs=constants)
    kernel = triton.compile(source, target=GPUTarget('cuda',86,32),
                            options={'num_warps':4,'enable_fp_fusion':False})
    ptx = kernel.asm['ptx']
    target = out/f'head-{dim}-masked-{masked}-sm86.ptx'
    target.write_text(ptx)
    # Compilation and static instruction inspection do NOT establish CUDA numerics.
    if 'fma.' in ptx.lower():
        raise AssertionError('Unexpected floating point fma instruction')
    if not any(x in ptx for x in ('cvt.rn.bf16.f32', 'cvt.rn.bf16x2.f32')):
        raise AssertionError('No explicit round-to-nearest BF16 cast found')
    if masked and 'add.rn.f32' not in ptx:
        raise AssertionError('Masked path missing separate FP32 addition')
    if 'mul.rn.f32' not in ptx:
        raise AssertionError('Missing separate FP32 multiplication')
    if '.ftz' in ptx:
        raise AssertionError('Unexpected explicit flush-to-zero modifier; inspect before GPU use')
    records.append(dict(head_dim=dim, masked=masked, target='sm86', triton=triton.__version__,
        ptx_sha256=hashlib.sha256(ptx.encode()).hexdigest(), num_warps=4,
        enable_fp_fusion=False, no_fma=True, explicit_bf16_rounding=True,
        gpu_executed=False, label='offline compiler control, NOT model/numerical evidence'))
print(json.dumps(records, indent=2))
(out/'offline-compilation.json').write_text(json.dumps(records, indent=2)+'\n')
