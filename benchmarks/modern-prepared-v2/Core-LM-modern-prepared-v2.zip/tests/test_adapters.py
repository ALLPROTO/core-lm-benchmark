"""Generated CPU unit fixtures only, NOT model evidence or GPU performance."""
import sys,unittest,hashlib,inspect
from pathlib import Path
from unittest.mock import patch
import torch
from transformers import Qwen2Config,Qwen2ForCausalLM,LlamaConfig,LlamaForCausalLM
from transformers.modeling_utils import ALL_ATTENTION_FUNCTIONS
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'implementation'))
import attention_adapters as a
import fused_scale_mask as f
torch.set_num_threads(1)

def oracle(scores,mask,scaling):
 x=(scores.float()*float(scaling)).to(torch.bfloat16)
 if mask is not None:x=(x.float()+mask.float()).to(torch.bfloat16)
 return x.float()

def model(family,dim):
 cls,config=(Qwen2ForCausalLM,Qwen2Config) if family=='qwen2' else (LlamaForCausalLM,LlamaConfig)
 c=config(vocab_size=37,hidden_size=dim*2,intermediate_size=128,num_hidden_layers=1,
          num_attention_heads=2,num_key_value_heads=1,max_position_embeddings=4096,attention_dropout=0.)
 c._attn_implementation='eager'
 m=cls(c).to(dtype=torch.bfloat16).eval();m.requires_grad_(False);return m

def forward(m,ids,prefix):
 with torch.inference_mode():
  p=m(ids[:,:prefix],use_cache=True,return_dict=True,logits_to_keep=1,output_attentions=False)
  cache=p.past_key_values
  pos=torch.arange(prefix,prefix+128)
  o=m(ids[:,prefix:prefix+128],past_key_values=cache,attention_mask=torch.ones((1,prefix+128),dtype=torch.long),
      position_ids=pos.unsqueeze(0),cache_position=pos,use_cache=False,return_dict=True,output_attentions=False)
  assert cache.get_seq_length()==prefix+128
  return p.logits.clone(),o.logits.clone(),cache.layers[0].keys.clone(),cache.layers[0].values.clone()

class Tests(unittest.TestCase):
 def test_source_guards(self):
  for family in ['qwen2','llama']:
   m=model(family,64);_,mod,_=a._model_module(m)
   self.assertEqual(hashlib.sha256(inspect.getsource(mod.eager_attention_forward).encode()).hexdigest(),a.EAGER_SHA256)
 def test_scale_rounding_all_finite_patterns(self):
  values=torch.arange(-32768,32768,dtype=torch.int32).to(torch.int16).view(torch.bfloat16)
  values=values[torch.isfinite(values)]
  for dim in [64,128]:
   for mv in [None,0.,torch.finfo(torch.bfloat16).min]:
    mask=None if mv is None else torch.full_like(values,mv)
    expected=values*(dim**-.5)
    if mask is not None:expected=expected+mask
    self.assertTrue(torch.equal(expected.float().view(torch.int32),oracle(values,mask,dim**-.5).view(torch.int32)))
 def test_candidate_real_api_wiring_cpu_oracle_only(self):
  for family,dim in [('qwen2',64),('qwen2',128),('llama',64)]:
   torch.manual_seed(9);m=model(family,dim);ids=torch.randint(0,37,(1,1666));ref=forward(m,ids,1537)
   try:
    with patch.object(f,'scale_mask_to_fp32',side_effect=oracle):
     stats=a.install_candidate(m);actual=forward(m,ids,1537)
    self.assertTrue(all(torch.equal(x,y) for x,y in zip(ref,actual)))
    self.assertEqual(stats['optimized_calls'],1);self.assertEqual(stats['short_native_calls'],1)
   finally:a.restore_adapter(m)
 def test_lower_right_real_api_and_registry_isolation(self):
  stock=ALL_ATTENTION_FUNCTIONS['sdpa']
  for family,dim in [('qwen2',64),('qwen2',128),('llama',64)]:
   torch.manual_seed(11);m=model(family,dim);ids=torch.randint(0,37,(1,258));ref=forward(m,ids,129)
   try:
    stats=a.install_lower_right_sdpa(m);actual=forward(m,ids,129)
    self.assertIs(ALL_ATTENTION_FUNCTIONS['sdpa'],stock)
    self.assertEqual(stats['prefill_calls'],1);self.assertEqual(stats['continuation_calls'],1)
    self.assertEqual(stats['semantic_mask_checks'],2)
    self.assertEqual(stats['observed_qkv_shapes'][1][1][-2],257)
    # BF16 SDPA math is not promised bit-exact to eager; unit wiring tolerance only.
    self.assertTrue(torch.allclose(ref[1],actual[1],atol=.015,rtol=.02))
   finally:a.restore_adapter(m)
 def test_rectangular_semantics_not_upper_left(self):
  from torch.nn.attention.bias import causal_lower_right
  q=torch.zeros((1,1,2,64));k=torch.zeros((1,1,5,64));v=torch.arange(5.).view(1,1,5,1).expand(1,1,5,64)
  with torch.inference_mode():
   good=torch.nn.functional.scaled_dot_product_attention(q,k,v,attn_mask=causal_lower_right(2,5))
   bad=torch.nn.functional.scaled_dot_product_attention(q,k,v,is_causal=True)
  self.assertTrue(torch.allclose(good[0,0,:,0],torch.tensor([1.5,2.])))
  self.assertFalse(torch.equal(good,bad))
  mask=torch.arange(5)[None,:] <= (torch.arange(2)[:,None]+3)
  a.validate_lower_right_mask(mask[None,None],q,k)
  a.validate_lower_right_mask(causal_lower_right(2,5),q,k)
  with self.assertRaises(ValueError):a.validate_lower_right_mask(causal_lower_right(2,4),q,k)
  with self.assertRaises(ValueError):a.validate_lower_right_mask(torch.ones((1,1,2,5),dtype=torch.bool),q,k)
  with self.assertRaises(ValueError):a.validate_lower_right_mask(None,q,k)
 def test_cpu_fused_rejected(self):
  with torch.inference_mode(),self.assertRaises(ValueError):f.scale_mask_to_fp32(torch.ones((1,1,2,2),dtype=torch.bfloat16),None,64**-.5)
 def test_masks_not_modified(self):
  q=torch.zeros((1,2,2,64));k=torch.zeros((1,1,5,64));mask=torch.arange(5)[None,:]<=(torch.arange(2)[:,None]+3)
  mask=mask[None,None];before=mask.clone();a.validate_lower_right_mask(mask,q,k);self.assertTrue(torch.equal(mask,before))
 def test_bad_source_and_duplicate_install_fail(self):
  m=model('qwen2',64)
  try:
   a.install_candidate(m)
   with self.assertRaises(RuntimeError):a.install_candidate(m)
  finally:a.restore_adapter(m)

if __name__=='__main__':unittest.main(verbosity=2)
