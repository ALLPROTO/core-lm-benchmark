"""Generated statistics/IO controls only, never GPU/model evidence."""
import json, math, sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'analysis'))
import analyze_matrix as a
class StatisticsTests(unittest.TestCase):
    def test_strict_fast(self):
        x=a.speed_statistics([.8]*6);self.assertTrue(x['no_slowdown_pass']);self.assertAlmostEqual(x['geometric_mean_ratio'],.8)
    def test_equal_not_pass(self): self.assertFalse(a.speed_statistics([1.]*6)['no_slowdown_pass'])
    def test_slow(self): self.assertEqual(a.speed_statistics([1.1]*6)['status'],'SLOWDOWN')
    def test_any_observed_slow_blocks(self): self.assertFalse(a.speed_statistics([.5]*5+[1.001])['no_slowdown_pass'])
    def test_invalid_counts_values(self):
        for x in ([.8]*5,[.8]*7,[0]*6,[float('nan')]*6,[-1]*6):
            with self.assertRaises(ValueError):a.speed_statistics(x)
    def test_reproducible(self):
        x=[.8,.81,.82,.83,.84,.85];self.assertEqual(a.speed_statistics(x),a.speed_statistics(x))
    def test_closed_form(self):
        x=[math.exp(v) for v in [-.2,-.19,-.18,-.17,-.16,-.15]];s=a.speed_statistics(x)
        self.assertAlmostEqual(s['geometric_mean_ratio'],math.exp(-.175));self.assertEqual(s['t_df'],5)
    def test_missing_worker_retained(self):
        with tempfile.TemporaryDirectory() as td:
            r=a.audit_run(Path(td),{}, {},'qwen05',4096,'sdpa','latency',0,None)
            self.assertFalse(r['available']);self.assertTrue(r['errors'])
    def test_memory_ratios(self):
        def r(v):return {'physical':{'device_max_bytes':v,'process_max_bytes':v},'metrics':{'session_memory':{'cumulative_peak_allocated_bytes':v,'cumulative_peak_reserved_bytes':v}}}
        x=a.summarize_memory([(r(100),r(80))]*6);self.assertEqual(x['device']['ratios'],[.8]*6)
    def test_csv_keeps_failed_modern(self):
        with tempfile.TemporaryDirectory() as td:
            c={'baseline':'sdpa','candidate':'fused','primary':True,'status':'FAILED_OR_INCOMPLETE','errors':['missing'],'speed':None,'memory':None,'no_slowdown_demonstrated':False}
            r={'cells':[{'model':'qwen05','length':4096,'comparisons':[c]}]}
            out=Path(td)/'out';a.write_outputs(r,out);self.assertIn('sdpa,fused',(out/'comparisons.csv').read_text())
if __name__=='__main__':unittest.main()
