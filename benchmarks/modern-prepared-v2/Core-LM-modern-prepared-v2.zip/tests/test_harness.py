"""Isolated generated unit fixtures, never model benchmark evidence."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'implementation'))
import benchmark_matrix as h
import unittest
import tempfile
import itertools
import hashlib
import types
import numpy as np

class Protocol(unittest.TestCase):
    def test_balanced_pair_orders(self):
        orders=h.balanced_orders(h.SEED)
        self.assertEqual(len(orders),6)
        for a,b in itertools.combinations(h.MODES,2):
            self.assertEqual(sum(x.index(a)<x.index(b) for x in orders),3)
    def test_seed_reproducible(self):
        self.assertEqual(h.execution_plan('matrix'),h.execution_plan('matrix'))
    def test_worker_count(self):
        p=h.execution_plan('matrix')
        self.assertEqual(sum(len(o)*4 for c in p['pair_orders'].values() for o in c.values()),432)
    def test_suffix_targets(self):
        for n in h.LENGTHS:
            x=h.workload_tokens(list(range(4096)),n,'memory')[0][1]
            self.assertEqual(len(x),n);self.assertEqual(x[-128:],list(range(3968,4096)))
    def test_quality_distinct_and_candidate_exercised(self):
        w=h.workload_tokens(list(range(4096)),2048,'quality')
        scored=[v for _,x in w for v in x[-128:]]
        self.assertEqual(scored,list(range(1920,2944)))
        self.assertTrue(all(len(x)-129>1536 for _,x in w))
    def test_unknown_rejected(self):
        with self.assertRaises(ValueError):h.execution_plan('matrix',['random'])
        with self.assertRaises(ValueError):h.workload_tokens([0]*4096,777,'memory')
    def test_no_peak_reset_or_cache_clear(self):
        import ast
        tree=ast.parse(Path(h.__file__).read_text())
        banned={'empty_cache','reset_peak_memory_stats','reset_max_memory_allocated','reset_max_memory_cached'}
        self.assertFalse(any(isinstance(x,ast.Attribute) and x.attr in banned for x in ast.walk(tree)))
    def test_quality_plan(self):
        p=h.execution_plan('quality');self.assertEqual(p['purposes'],['quality'])
        self.assertEqual([x['length'] for x in p['cells']],[2048]*3)
    def test_reference_portable(self):
        with tempfile.TemporaryDirectory(prefix='unit-only-') as d:
            root=Path(d);raw=root/'memory';raw.mkdir();late=root/'latency';late.mkdir()
            h.write_json(raw/'metrics.json',{'rounds':[{'blocks':[{'block':'x','raw_logits_file':'x.npy'}]}]})
            p,_=h.canonical_raw(late,{'block':'x','raw_reference_metrics':'../memory/metrics.json'})
            self.assertEqual(p,raw/'x.npy')
    def test_sdpa_difference_reports_not_throws(self):
        with tempfile.TemporaryDirectory(prefix='unit-only-') as d:
            dirs=[Path(d)/x for x in ('eager','sdpa')]
            for i,p in enumerate(dirs):
                p.mkdir();a=np.zeros((128,4),dtype=np.float32);a[:,i]=1
                np.save(p/'raw.npy',a)
                nll=float(np.log(np.exp(a[0].astype(np.float64)).sum())-a[0,0])
                h.write_json(p/'metrics.json',{'model':'unit','length':512,'mode':p.name,'purpose':'probe','rounds':[{'blocks':[{'block':'x','raw_logits_file':'raw.npy','raw_logits_sha256':h.sha256(p/'raw.npy'),'nll_per_token_fp32_torch':[nll]*128}]}]})
                h.write_json(p/'tokens.json',{'blocks':[{'block':'x','targets':[0]*128}]})
            r=h.compare_outputs(*dirs,Path(d)/'comparison.json')
            self.assertFalse(r['exact_quality_gate']);self.assertFalse(r['legacy_compatibility_gate'])
            self.assertEqual(r['top1_agreement'],0)
    def test_quality_gate_calls_both_arms(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory(prefix='unit-only-') as d:
            root=Path(d)
            h.write_json(root/'quality/qwen05-L2048/comparison-0-eager-vs-fused.json',{'scored_tokens':1024})
            with patch.object(h,'probe_status',return_value=(True,None)) as check:
                self.assertEqual(h.quality_status(root,'qwen05',{},'GPU-unit'),(True,None))
                self.assertEqual([x.args[3] for x in check.call_args_list],['eager','fused'])
                self.assertTrue(all(x.kwargs['stage']=='quality' for x in check.call_args_list))
    def test_quality_failure_returns_candidate_reason(self):
        from unittest.mock import patch
        with patch.object(h,'probe_status',return_value=(False,'Fused exact gate failed')):
            ok,why=h.quality_status(Path('/unit-only-missing'),'qwen05',{})
            self.assertFalse(ok);self.assertIn('exact gate failed',why)
    def test_quality_missing_evidence_does_not_raise(self):
        ok,why=h.quality_status(Path('/unit-only-missing'),'qwen05',{})
        self.assertFalse(ok);self.assertIn('Quality',why)
    def test_quality_insufficient_tokens_rejected(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory(prefix='unit-only-') as d:
            root=Path(d)
            h.write_json(root/'quality/qwen05-L2048/comparison-0-eager-vs-fused.json',{'scored_tokens':128})
            with patch.object(h,'probe_status',return_value=(True,None)):
                self.assertFalse(h.quality_status(root,'qwen05',{})[0])
    def test_fused_counter_contract_quality_and_latency(self):
        for lengths,purpose in [([2048]*8,'quality'),([4096]*11,'latency'),([512]*3,'memory')]:
            layers=24;optimized=layers*sum(n-129>1536 for n in lengths);total=2*layers*len(lengths)
            stats={'calls':total,'optimized_calls':optimized,'short_native_calls':total-optimized,
                   'fused_scale_mask_cast_calls':optimized,'alias_softmax_calls':optimized}
            self.assertTrue(h.validate_adapter_counts('fused',stats,layers,lengths,purpose)['pass'])
            stats['optimized_calls']=optimized+1
            with self.assertRaisesRegex(RuntimeError,'invocation contract'):
                h.validate_adapter_counts('fused',stats,layers,lengths,purpose)
    def test_lower_right_counter_contract(self):
        for purpose,checks in [('quality',384),('latency',0)]:
            stats={'calls':384,'prefill_calls':192,'continuation_calls':192,
                   'semantic_mask_checks':checks,'validate_masks':purpose=='quality'}
            self.assertTrue(h.validate_adapter_counts('sdpa_lower_right',stats,24,[2048]*8,purpose)['pass'])
            stats['semantic_mask_checks']=1
            with self.assertRaises(RuntimeError):
                h.validate_adapter_counts('sdpa_lower_right',stats,24,[2048]*8,purpose)
    def test_missing_adapter_cannot_masquerade(self):
        with self.assertRaises(RuntimeError):h.validate_adapter_counts('fused',None,24,[4096],'probe')
        self.assertTrue(h.validate_adapter_counts('sdpa',None,24,[4096],'probe')['pass'])
    def test_probe_uuid_prefix_normalization(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory(prefix='unit-only-') as d:
            root=Path(d);run=root/'probe/qwen05-L4096/repeat-0-sdpa'
            h.write_json(run/'process-exit.json',{'returncode':0})
            reg={'models':{'qwen05':{'revision':'unit','token_file_sha256':'unit'}}}
            h.write_json(root/'registry.json',reg)
            source=root/'harness';source.mkdir()
            for name in ('benchmark_matrix.py','attention_adapters.py','fused_scale_mask.py'):
                (source/name).write_bytes((Path(h.__file__).parent/name).read_bytes())
            metrics={'model':'qwen05','length':4096,'mode':'sdpa','purpose':'probe',
                     'model_revision':'unit','runtime':h.RUNTIME,'diagnostic_semantics':{'pass':True}}
            for observed,requested in [('unit-uuid','GPU-unit-uuid'),('GPU-unit-uuid','unit-uuid')]:
                metrics['gpu_uuid']=observed;h.write_json(run/'metrics.json',metrics)
                self.assertTrue(h.probe_status(root,'qwen05',4096,'sdpa',reg,requested)[0])
                ok,why=h.probe_status(root,'qwen05',4096,'sdpa',reg,'GPU-other-uuid')
                self.assertFalse(ok);self.assertEqual(why,'Probe GPU UUID mismatch')
    def test_tiny_qwen_lower_right_probe_integration(self):
        import torch
        from transformers import Qwen2Config,Qwen2ForCausalLM
        import attention_adapters as adapters
        torch.set_num_threads(1);torch.manual_seed(123)
        c=Qwen2Config(vocab_size=37,hidden_size=128,intermediate_size=128,
            num_hidden_layers=1,num_attention_heads=2,num_key_value_heads=1,
            max_position_embeddings=256,attention_dropout=0.)
        c._attn_implementation='eager'
        model=Qwen2ForCausalLM(c).to(dtype=torch.bfloat16).eval()
        model.requires_grad_(False);ids=torch.randint(0,37,(1,7));native=torch.nn.functional.scaled_dot_product_attention
        probe=None
        def forward(observer):
            with torch.inference_mode(),torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU]) as prof:
                if observer:observer.expected=(4,4,'prefill')
                pre=model(ids[:,:4],use_cache=True,return_dict=True,logits_to_keep=1)
                cache=pre.past_key_values
                if observer:observer.expected=(2,6,'continuation')
                pos=torch.arange(4,6)
                out=model(ids[:,4:6],past_key_values=cache,attention_mask=torch.ones((1,6),dtype=torch.long),
                    position_ids=pos.unsqueeze(0),cache_position=pos,use_cache=False,return_dict=True)
                self.assertEqual(cache.get_seq_length(),6)
            ops=[e.name for e in prof.events() if 'scaled_dot_product' in e.name]
            return pre.logits.clone(),out.logits.clone(),ops
        try:
            adapters.install_lower_right_sdpa(model,validate_masks=True)
            expected=forward(None)
            probe=h.SemanticProbe(model,'sdpa_lower_right');actual=forward(probe)
            self.assertTrue(torch.equal(expected[0],actual[0]));self.assertTrue(torch.equal(expected[1],actual[1]))
            self.assertEqual(expected[2],actual[2]);self.assertTrue(actual[2])
            self.assertEqual({r['phase'] for r in probe.records},{'prefill','continuation'})
            self.assertEqual(probe.records[-1]['mask_kind'],'CausalBias.lower_right')
        finally:
            if probe:probe.close()
            adapters.restore_adapter(model)
        self.assertIs(torch.nn.functional.scaled_dot_product_attention,native)
    def test_registry_integrity(self):
        with tempfile.TemporaryDirectory(prefix='unit-only-') as d:
            p=Path(d);(p/'snap').mkdir();(p/'snap/config.json').write_text('{}');(p/'snap/model.safetensors').write_bytes(b'unit')
            ids=list(range(4096));h.write_json(p/'tokens.json',{'token_ids':ids,'sha256':hashlib.sha256(np.asarray(ids,dtype='<u4').tobytes()).hexdigest()})
            reg={'runtime':h.RUNTIME,'lengths':h.LENGTHS,'models':{'qwen05':{'token_file':'tokens.json','token_file_sha256':h.sha256(p/'tokens.json'),'snapshot_path':'snap','config_sha256':h.sha256(p/'snap/config.json'),'assets':[{'path':'model.safetensors','bytes':4}]}}}
            h.write_json(p/'registry.json',reg);h.load_inputs(p/'registry.json','qwen05')
            (p/'tokens.json').write_text('{}')
            with self.assertRaisesRegex(ValueError,'digest mismatch'):h.load_inputs(p/'registry.json','qwen05')

class ActualTorchSemanticUnit(unittest.TestCase):
    def setUp(self):
        import torch
        self.t=torch
        self.p=h.SemanticProbe(types.SimpleNamespace(),'sdpa')
        self.q=torch.zeros((1,1,2,4));self.k=torch.zeros((1,1,5,4))
        self.p.expected=(2,5,'continuation')
    def tearDown(self):self.p.close()
    def test_valid_rectangular_bias(self):
        from torch.nn.attention.bias import causal_lower_right
        self.p.check(self.q,self.k,self.k,causal_lower_right(2,5),False,'unit')
        self.assertTrue(self.p.records[0]['prefix_in_attention_verified'])
    def test_actual_sdpa_dispatch_transparent_and_restored(self):
        from torch.nn.attention.bias import causal_lower_right
        t=self.t;f=t.nn.functional
        values=t.arange(5,dtype=t.float32).reshape(1,1,5,1).expand(1,1,5,4).contiguous()
        explicit=(t.arange(5)[None,:]<=t.arange(3,5)[:,None])[None,None]
        observer=f.scaled_dot_product_attention
        for mask in (causal_lower_right(2,5),explicit):
            # Native reference must also have native public function identity.
            f.scaled_dot_product_attention=self.p.original
            try:expected=f.scaled_dot_product_attention(self.q,self.k,values,attn_mask=mask)
            finally:f.scaled_dot_product_attention=observer
            actual=f.scaled_dot_product_attention(self.q,self.k,values,attn_mask=mask)
            self.assertTrue(t.equal(expected,actual))
            self.assertTrue(t.equal(actual[0,0,:,0],t.tensor([1.5,2.])))
            self.assertIs(f.scaled_dot_product_attention,observer)
        self.p.close()
        self.assertIs(f.scaled_dot_product_attention,self.p.original)
    def test_dispatch_error_restores_observer(self):
        t=self.t;f=t.nn.functional;observer=f.scaled_dot_product_attention
        from torch.nn.attention.bias import causal_lower_right
        with self.assertRaises((RuntimeError,ValueError)):
            f.scaled_dot_product_attention(self.q,self.k,self.k.double(),attn_mask=causal_lower_right(2,5))
        self.assertIs(f.scaled_dot_product_attention,observer)
    def test_prefix_truncation_rejected(self):
        with self.assertRaisesRegex(RuntimeError,'discarded prefix'):
            self.p.check(self.q,self.k[:,:,:2],self.k[:,:,:2],None,True,'unit')
    def test_wrong_causal_alignment_rejected(self):
        with self.assertRaisesRegex(RuntimeError,'upper-left'):
            self.p.check(self.q,self.k,self.k,None,True,'unit')
    def test_explicit_mask_and_future_leak(self):
        t=self.t;mask=t.arange(5)[None,:]<=t.arange(3,5)[:,None]
        self.p.check(self.q,self.k,self.k,mask[None,None],False,'unit')
        with self.assertRaises((ValueError,RuntimeError)):
            self.p.check(self.q,self.k,self.k,t.ones((1,1,2,5),dtype=t.bool),False,'unit')

if __name__=='__main__':unittest.main()
