"""Lossless backup of experiment evidence; never deletes or modifies originals.

Reproducibly downloadable public weights/runtime are represented by their pinned
digests and package manifests, not duplicated. All run data and source snapshots
are included. Identical files use TAR hardlinks, with every original path/hash in
the manifest. No files from another task, account credentials or browser state.
"""
import datetime,gzip,hashlib,json,os,tarfile
from pathlib import Path
root=Path('/workspace/corelm-modern-study-20261112')
archive=Path('/workspace/Core-LM-modern-evidence.tar.gz')
assert not archive.exists(),'Never overwrite earlier evidence'
exclude={'runtime','hf-cache','evidence-manifest.json'}
files=[p for p in sorted(root.rglob('*')) if p.is_file() and p.relative_to(root).parts[0] not in exclude and '__pycache__' not in p.parts]
rows=[]
for p in files:
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 rows.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':h})
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'All experiment evidence except redownloadable pinned runtime/model cache and bytecode; originals preserved','files':rows}
mp=root/'evidence-manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n')
seen={}
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 tar.add(mp,arcname='evidence-manifest.json')
 for p,row in zip(files,rows):
  key=(row['sha256'],row['bytes']);info=tar.gettarinfo(str(p),arcname=row['path'])
  if key in seen:
   info.type=tarfile.LNKTYPE;info.linkname=seen[key];info.size=0;tar.addfile(info)
  else:
   seen[key]=row['path']
   with p.open('rb') as f:tar.addfile(info,f)
with archive.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':h,'files':len(rows),'unique_files':len(seen)},indent=2),flush=True)
