#!/bin/bash
set -euo pipefail
cd /workspace/corelm-modern-study-20261112
exec > >(tee -a bootstrap.log) 2>&1
trap 'rc=$?; printf "BOOTSTRAP_EXIT %s " "$rc"; date -u +%FT%TZ; exit "$rc"' EXIT
printf 'BOOTSTRAP_START '; date -u +%FT%TZ
nvidia-smi --query-gpu=name,uuid,driver_version,memory.total --format=csv | tee gpu-before.csv
df -h /workspace
python3 -m venv runtime
runtime/bin/python -m pip install --no-cache-dir torch==2.13.0 --index-url https://download.pytorch.org/whl/cu130
runtime/bin/python -m pip install --no-cache-dir --index-url https://pypi.org/simple transformers==5.14.1 numpy==2.5.1 pyarrow==23.0.1 nvidia-ml-py==13.615.71 huggingface_hub==1.25.1 safetensors==0.8.0 tokenizers==0.22.2
runtime/bin/python -m pip freeze > actual-pip-freeze.txt
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_DISABLE_TELEMETRY=1
runtime/bin/python prepared-matrix/execution/verify_assets.py --registry prepared-matrix/registry.json --out verified-assets-before.json --download
runtime/bin/python - <<'PY'
import torch,transformers,triton,json,platform,numpy
assert torch.__version__=='2.13.0+cu130'
assert transformers.__version__=='5.14.1' and triton.__version__=='3.7.1'
assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
print('RUNTIME',torch.__version__,torch.version.cuda,transformers.__version__,triton.__version__,numpy.__version__,platform.python_version(),torch.cuda.get_device_name(),torch.cuda.get_arch_list(),str(torch.cuda.get_device_properties(0).uuid))
PY
GPU_UUID=$(nvidia-smi --query-gpu=uuid --format=csv,noheader | head -1)
runtime/bin/python prepared-matrix/instrumentation/capability_check.py --uuid "$GPU_UUID" --output capability.json
df -h /workspace
printf 'BOOTSTRAP_COMPLETE '; date -u +%FT%TZ
