#!/bin/bash
set -euo pipefail
cd /workspace/corelm-modern-study-20261112
STAGE=${1:?probe,quality,matrix required}
case "$STAGE" in probe|quality|matrix) ;; *) exit 2;; esac
exec > >(tee -a "$STAGE.log") 2>&1
trap 'rc=$?; printf "STAGE_EXIT %s %s " "$STAGE" "$rc"; date -u +%FT%TZ; exit "$rc"' EXIT
export HF_HOME="$PWD/hf-cache" HF_HUB_DISABLE_TELEMETRY=1
export PYTHONDONTWRITEBYTECODE=1 TOKENIZERS_PARALLELISM=false CUBLAS_WORKSPACE_CONFIG=:4096:8
export TRITON_CACHE_DIR="$PWD/triton-cache"
GPU_UUID=$(nvidia-smi --query-gpu=uuid --format=csv,noheader | head -1)
printf 'STAGE_START %s ' "$STAGE"; date -u +%FT%TZ
extra=()
if [ "$STAGE" = matrix ]; then
  extra=(--quality-root "$PWD/quality" --probe-root "$PWD/probe" --monitor "$PWD/prepared-matrix/instrumentation/lifecycle_monitor.py" --uuid "$GPU_UUID" --interval-ms 1)
fi
# Time cap terminates this experiment's process tree, not the GPU or user data.
# Parent verifies saved backup and stops the paid pod through Runpod afterwards.
timeout --signal=TERM 10800 runtime/bin/python prepared-matrix/implementation/benchmark_matrix.py "$STAGE" --registry "$PWD/prepared-matrix/registry.json" --out "$PWD/$STAGE" "${extra[@]}"
printf 'STAGE_COMPLETE %s ' "$STAGE"; date -u +%FT%TZ
