"""Download public pinned assets and verify every actual byte before model use."""
import argparse, datetime, hashlib, json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--registry',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--download',action='store_true');a=p.parse_args()
a.registry=a.registry.resolve();reg=json.loads(a.registry.read_text());rows=[]
for alias,m in reg['models'].items():
    expected=(a.registry.parent/m['snapshot_path']).resolve()
    if a.download:
        from huggingface_hub import snapshot_download
        # Ordinary public bytes; no token, remote code or account creation.
        actual=Path(snapshot_download(m['repository'],revision=m['revision'],cache_dir=expected.parents[2],allow_patterns=[x['path'] for x in m['assets']],token=False)).resolve()
        assert actual==expected,(actual,expected)
    for asset in m['assets']:
        path=expected/asset['path']
        with path.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
        assert digest==asset['sha256'] and path.stat().st_size==asset['bytes'],str(path)
        rows.append({'model':alias,**asset,'verified':True})
        print('VERIFIED',alias,asset['path'],asset['bytes'],flush=True)
a.out.write_text(json.dumps({'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'registry_sha256':hashlib.sha256(a.registry.read_bytes()).hexdigest(),'assets':rows},indent=2)+'\n')
