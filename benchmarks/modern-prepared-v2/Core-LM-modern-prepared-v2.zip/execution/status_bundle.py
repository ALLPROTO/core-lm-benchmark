"""Small downloadable status bundle, no model weights/raw logits/large traces."""
import json,zipfile
from pathlib import Path
root=Path('/workspace/corelm-modern-study-20261112')
dest=Path('/workspace/modern-status.zip')
with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted(root.rglob('*')):
  if not p.is_file() or p.relative_to(root).parts[0] in {'runtime','hf-cache','triton-cache'}:continue
  if p.name=='diagnostic-trace.json' or p.name=='samples.jsonl' or p.suffix in {'.npy','.pickle','.pt','.bin'}:continue
  if p.stat().st_size>10_000_000:continue
  if p.suffix in {'.json','.jsonl','.log','.txt','.csv','.md','.py','.sh'}:z.write(p,p.relative_to(root))
print('STATUS_BUNDLE',dest,dest.stat().st_size,flush=True)
